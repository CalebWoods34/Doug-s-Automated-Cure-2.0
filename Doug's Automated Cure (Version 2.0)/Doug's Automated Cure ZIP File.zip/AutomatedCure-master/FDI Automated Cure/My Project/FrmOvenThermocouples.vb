﻿Public Class FrmOvenThermocouples

End Class
