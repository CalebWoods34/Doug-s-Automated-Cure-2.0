﻿Public Class FrmThermocouples

End Class