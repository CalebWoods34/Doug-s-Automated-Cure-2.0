﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class OvenThermocouples
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TCCheckBox1 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox9 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox2 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox10 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox3 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox11 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox4 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox12 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox5 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox13 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox6 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox14 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox7 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox15 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox8 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox16 = New System.Windows.Forms.CheckBox()
        Me.OkButton1 = New System.Windows.Forms.Button()
        Me.TCCheckBox17 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox25 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox18 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox19 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox20 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox21 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox22 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox23 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox24 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox26 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox27 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox28 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox29 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox30 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox31 = New System.Windows.Forms.CheckBox()
        Me.TCCheckBox32 = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(250, 26)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Which thermocouples are connected to this part?" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Uncheck thermocouples not connec" &
    "ted to this part."
        '
        'TCCheckBox1
        '
        Me.TCCheckBox1.AutoSize = True
        Me.TCCheckBox1.Location = New System.Drawing.Point(15, 52)
        Me.TCCheckBox1.Name = "TCCheckBox1"
        Me.TCCheckBox1.Size = New System.Drawing.Size(46, 17)
        Me.TCCheckBox1.TabIndex = 1
        Me.TCCheckBox1.Tag = "1"
        Me.TCCheckBox1.Text = "TC1"
        Me.TCCheckBox1.UseVisualStyleBackColor = True
        '
        'TCCheckBox9
        '
        Me.TCCheckBox9.AutoSize = True
        Me.TCCheckBox9.Location = New System.Drawing.Point(76, 52)
        Me.TCCheckBox9.Name = "TCCheckBox9"
        Me.TCCheckBox9.Size = New System.Drawing.Size(46, 17)
        Me.TCCheckBox9.TabIndex = 9
        Me.TCCheckBox9.Tag = "9"
        Me.TCCheckBox9.Text = "TC9"
        Me.TCCheckBox9.UseVisualStyleBackColor = True
        '
        'TCCheckBox2
        '
        Me.TCCheckBox2.AutoSize = True
        Me.TCCheckBox2.Location = New System.Drawing.Point(15, 75)
        Me.TCCheckBox2.Name = "TCCheckBox2"
        Me.TCCheckBox2.Size = New System.Drawing.Size(46, 17)
        Me.TCCheckBox2.TabIndex = 2
        Me.TCCheckBox2.Tag = "2"
        Me.TCCheckBox2.Text = "TC2"
        Me.TCCheckBox2.UseVisualStyleBackColor = True
        '
        'TCCheckBox10
        '
        Me.TCCheckBox10.AutoSize = True
        Me.TCCheckBox10.Location = New System.Drawing.Point(76, 75)
        Me.TCCheckBox10.Name = "TCCheckBox10"
        Me.TCCheckBox10.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox10.TabIndex = 10
        Me.TCCheckBox10.Tag = "10"
        Me.TCCheckBox10.Text = "TC10"
        Me.TCCheckBox10.UseVisualStyleBackColor = True
        '
        'TCCheckBox3
        '
        Me.TCCheckBox3.AutoSize = True
        Me.TCCheckBox3.Location = New System.Drawing.Point(15, 98)
        Me.TCCheckBox3.Name = "TCCheckBox3"
        Me.TCCheckBox3.Size = New System.Drawing.Size(46, 17)
        Me.TCCheckBox3.TabIndex = 3
        Me.TCCheckBox3.Tag = "3"
        Me.TCCheckBox3.Text = "TC3"
        Me.TCCheckBox3.UseVisualStyleBackColor = True
        '
        'TCCheckBox11
        '
        Me.TCCheckBox11.AutoSize = True
        Me.TCCheckBox11.Location = New System.Drawing.Point(76, 98)
        Me.TCCheckBox11.Name = "TCCheckBox11"
        Me.TCCheckBox11.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox11.TabIndex = 11
        Me.TCCheckBox11.Tag = "11"
        Me.TCCheckBox11.Text = "TC11"
        Me.TCCheckBox11.UseVisualStyleBackColor = True
        '
        'TCCheckBox4
        '
        Me.TCCheckBox4.AutoSize = True
        Me.TCCheckBox4.Location = New System.Drawing.Point(15, 121)
        Me.TCCheckBox4.Name = "TCCheckBox4"
        Me.TCCheckBox4.Size = New System.Drawing.Size(46, 17)
        Me.TCCheckBox4.TabIndex = 4
        Me.TCCheckBox4.Tag = "4"
        Me.TCCheckBox4.Text = "TC4"
        Me.TCCheckBox4.UseVisualStyleBackColor = True
        '
        'TCCheckBox12
        '
        Me.TCCheckBox12.AutoSize = True
        Me.TCCheckBox12.Location = New System.Drawing.Point(76, 121)
        Me.TCCheckBox12.Name = "TCCheckBox12"
        Me.TCCheckBox12.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox12.TabIndex = 12
        Me.TCCheckBox12.Tag = "12"
        Me.TCCheckBox12.Text = "TC12"
        Me.TCCheckBox12.UseVisualStyleBackColor = True
        '
        'TCCheckBox5
        '
        Me.TCCheckBox5.AutoSize = True
        Me.TCCheckBox5.Location = New System.Drawing.Point(15, 144)
        Me.TCCheckBox5.Name = "TCCheckBox5"
        Me.TCCheckBox5.Size = New System.Drawing.Size(46, 17)
        Me.TCCheckBox5.TabIndex = 5
        Me.TCCheckBox5.Tag = "5"
        Me.TCCheckBox5.Text = "TC5"
        Me.TCCheckBox5.UseVisualStyleBackColor = True
        '
        'TCCheckBox13
        '
        Me.TCCheckBox13.AutoSize = True
        Me.TCCheckBox13.Location = New System.Drawing.Point(76, 144)
        Me.TCCheckBox13.Name = "TCCheckBox13"
        Me.TCCheckBox13.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox13.TabIndex = 13
        Me.TCCheckBox13.Tag = "13"
        Me.TCCheckBox13.Text = "TC13"
        Me.TCCheckBox13.UseVisualStyleBackColor = True
        '
        'TCCheckBox6
        '
        Me.TCCheckBox6.AutoSize = True
        Me.TCCheckBox6.Location = New System.Drawing.Point(15, 167)
        Me.TCCheckBox6.Name = "TCCheckBox6"
        Me.TCCheckBox6.Size = New System.Drawing.Size(46, 17)
        Me.TCCheckBox6.TabIndex = 6
        Me.TCCheckBox6.Tag = "6"
        Me.TCCheckBox6.Text = "TC6"
        Me.TCCheckBox6.UseVisualStyleBackColor = True
        '
        'TCCheckBox14
        '
        Me.TCCheckBox14.AutoSize = True
        Me.TCCheckBox14.Location = New System.Drawing.Point(76, 167)
        Me.TCCheckBox14.Name = "TCCheckBox14"
        Me.TCCheckBox14.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox14.TabIndex = 14
        Me.TCCheckBox14.Tag = "14"
        Me.TCCheckBox14.Text = "TC14"
        Me.TCCheckBox14.UseVisualStyleBackColor = True
        '
        'TCCheckBox7
        '
        Me.TCCheckBox7.AutoSize = True
        Me.TCCheckBox7.Location = New System.Drawing.Point(15, 190)
        Me.TCCheckBox7.Name = "TCCheckBox7"
        Me.TCCheckBox7.Size = New System.Drawing.Size(46, 17)
        Me.TCCheckBox7.TabIndex = 7
        Me.TCCheckBox7.Tag = "7"
        Me.TCCheckBox7.Text = "TC7"
        Me.TCCheckBox7.UseVisualStyleBackColor = True
        '
        'TCCheckBox15
        '
        Me.TCCheckBox15.AutoSize = True
        Me.TCCheckBox15.Location = New System.Drawing.Point(76, 190)
        Me.TCCheckBox15.Name = "TCCheckBox15"
        Me.TCCheckBox15.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox15.TabIndex = 15
        Me.TCCheckBox15.Tag = "15"
        Me.TCCheckBox15.Text = "TC15"
        Me.TCCheckBox15.UseVisualStyleBackColor = True
        '
        'TCCheckBox8
        '
        Me.TCCheckBox8.AutoSize = True
        Me.TCCheckBox8.Location = New System.Drawing.Point(15, 213)
        Me.TCCheckBox8.Name = "TCCheckBox8"
        Me.TCCheckBox8.Size = New System.Drawing.Size(46, 17)
        Me.TCCheckBox8.TabIndex = 8
        Me.TCCheckBox8.Tag = "8"
        Me.TCCheckBox8.Text = "TC8"
        Me.TCCheckBox8.UseVisualStyleBackColor = True
        '
        'TCCheckBox16
        '
        Me.TCCheckBox16.AutoSize = True
        Me.TCCheckBox16.Location = New System.Drawing.Point(76, 213)
        Me.TCCheckBox16.Name = "TCCheckBox16"
        Me.TCCheckBox16.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox16.TabIndex = 16
        Me.TCCheckBox16.Tag = "16"
        Me.TCCheckBox16.Text = "TC16"
        Me.TCCheckBox16.UseVisualStyleBackColor = True
        '
        'OkButton1
        '
        Me.OkButton1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.OkButton1.Location = New System.Drawing.Point(71, 240)
        Me.OkButton1.Name = "OkButton1"
        Me.OkButton1.Size = New System.Drawing.Size(107, 23)
        Me.OkButton1.TabIndex = 33
        Me.OkButton1.Text = "OK"
        Me.OkButton1.UseVisualStyleBackColor = True
        '
        'TCCheckBox17
        '
        Me.TCCheckBox17.AutoSize = True
        Me.TCCheckBox17.Location = New System.Drawing.Point(132, 52)
        Me.TCCheckBox17.Name = "TCCheckBox17"
        Me.TCCheckBox17.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox17.TabIndex = 17
        Me.TCCheckBox17.Tag = "17"
        Me.TCCheckBox17.Text = "TC17"
        Me.TCCheckBox17.UseVisualStyleBackColor = True
        '
        'TCCheckBox25
        '
        Me.TCCheckBox25.AutoSize = True
        Me.TCCheckBox25.Location = New System.Drawing.Point(193, 52)
        Me.TCCheckBox25.Name = "TCCheckBox25"
        Me.TCCheckBox25.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox25.TabIndex = 25
        Me.TCCheckBox25.Tag = "25"
        Me.TCCheckBox25.Text = "TC25"
        Me.TCCheckBox25.UseVisualStyleBackColor = True
        '
        'TCCheckBox18
        '
        Me.TCCheckBox18.AutoSize = True
        Me.TCCheckBox18.Location = New System.Drawing.Point(132, 75)
        Me.TCCheckBox18.Name = "TCCheckBox18"
        Me.TCCheckBox18.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox18.TabIndex = 18
        Me.TCCheckBox18.Tag = "18"
        Me.TCCheckBox18.Text = "TC18"
        Me.TCCheckBox18.UseVisualStyleBackColor = True
        '
        'TCCheckBox19
        '
        Me.TCCheckBox19.AutoSize = True
        Me.TCCheckBox19.Location = New System.Drawing.Point(132, 98)
        Me.TCCheckBox19.Name = "TCCheckBox19"
        Me.TCCheckBox19.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox19.TabIndex = 19
        Me.TCCheckBox19.Tag = "19"
        Me.TCCheckBox19.Text = "TC19"
        Me.TCCheckBox19.UseVisualStyleBackColor = True
        '
        'TCCheckBox20
        '
        Me.TCCheckBox20.AutoSize = True
        Me.TCCheckBox20.Location = New System.Drawing.Point(132, 121)
        Me.TCCheckBox20.Name = "TCCheckBox20"
        Me.TCCheckBox20.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox20.TabIndex = 20
        Me.TCCheckBox20.Tag = "20"
        Me.TCCheckBox20.Text = "TC20"
        Me.TCCheckBox20.UseVisualStyleBackColor = True
        '
        'TCCheckBox21
        '
        Me.TCCheckBox21.AutoSize = True
        Me.TCCheckBox21.Location = New System.Drawing.Point(132, 144)
        Me.TCCheckBox21.Name = "TCCheckBox21"
        Me.TCCheckBox21.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox21.TabIndex = 21
        Me.TCCheckBox21.Tag = "21"
        Me.TCCheckBox21.Text = "TC21"
        Me.TCCheckBox21.UseVisualStyleBackColor = True
        '
        'TCCheckBox22
        '
        Me.TCCheckBox22.AutoSize = True
        Me.TCCheckBox22.Location = New System.Drawing.Point(132, 167)
        Me.TCCheckBox22.Name = "TCCheckBox22"
        Me.TCCheckBox22.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox22.TabIndex = 22
        Me.TCCheckBox22.Tag = "22"
        Me.TCCheckBox22.Text = "TC22"
        Me.TCCheckBox22.UseVisualStyleBackColor = True
        '
        'TCCheckBox23
        '
        Me.TCCheckBox23.AutoSize = True
        Me.TCCheckBox23.Location = New System.Drawing.Point(132, 190)
        Me.TCCheckBox23.Name = "TCCheckBox23"
        Me.TCCheckBox23.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox23.TabIndex = 23
        Me.TCCheckBox23.Tag = "23"
        Me.TCCheckBox23.Text = "TC23"
        Me.TCCheckBox23.UseVisualStyleBackColor = True
        '
        'TCCheckBox24
        '
        Me.TCCheckBox24.AutoSize = True
        Me.TCCheckBox24.Location = New System.Drawing.Point(132, 213)
        Me.TCCheckBox24.Name = "TCCheckBox24"
        Me.TCCheckBox24.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox24.TabIndex = 24
        Me.TCCheckBox24.Tag = "24"
        Me.TCCheckBox24.Text = "TC24"
        Me.TCCheckBox24.UseVisualStyleBackColor = True
        '
        'TCCheckBox26
        '
        Me.TCCheckBox26.AutoSize = True
        Me.TCCheckBox26.Location = New System.Drawing.Point(193, 75)
        Me.TCCheckBox26.Name = "TCCheckBox26"
        Me.TCCheckBox26.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox26.TabIndex = 26
        Me.TCCheckBox26.Tag = "26"
        Me.TCCheckBox26.Text = "TC26"
        Me.TCCheckBox26.UseVisualStyleBackColor = True
        '
        'TCCheckBox27
        '
        Me.TCCheckBox27.AutoSize = True
        Me.TCCheckBox27.Location = New System.Drawing.Point(193, 98)
        Me.TCCheckBox27.Name = "TCCheckBox27"
        Me.TCCheckBox27.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox27.TabIndex = 27
        Me.TCCheckBox27.Tag = "27"
        Me.TCCheckBox27.Text = "TC27"
        Me.TCCheckBox27.UseVisualStyleBackColor = True
        '
        'TCCheckBox28
        '
        Me.TCCheckBox28.AutoSize = True
        Me.TCCheckBox28.Location = New System.Drawing.Point(193, 121)
        Me.TCCheckBox28.Name = "TCCheckBox28"
        Me.TCCheckBox28.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox28.TabIndex = 28
        Me.TCCheckBox28.Tag = "28"
        Me.TCCheckBox28.Text = "TC28"
        Me.TCCheckBox28.UseVisualStyleBackColor = True
        '
        'TCCheckBox29
        '
        Me.TCCheckBox29.AutoSize = True
        Me.TCCheckBox29.Location = New System.Drawing.Point(193, 144)
        Me.TCCheckBox29.Name = "TCCheckBox29"
        Me.TCCheckBox29.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox29.TabIndex = 29
        Me.TCCheckBox29.Tag = "29"
        Me.TCCheckBox29.Text = "TC29"
        Me.TCCheckBox29.UseVisualStyleBackColor = True
        '
        'TCCheckBox30
        '
        Me.TCCheckBox30.AutoSize = True
        Me.TCCheckBox30.Location = New System.Drawing.Point(193, 167)
        Me.TCCheckBox30.Name = "TCCheckBox30"
        Me.TCCheckBox30.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox30.TabIndex = 30
        Me.TCCheckBox30.Tag = "30"
        Me.TCCheckBox30.Text = "TC30"
        Me.TCCheckBox30.UseVisualStyleBackColor = True
        '
        'TCCheckBox31
        '
        Me.TCCheckBox31.AutoSize = True
        Me.TCCheckBox31.Location = New System.Drawing.Point(193, 190)
        Me.TCCheckBox31.Name = "TCCheckBox31"
        Me.TCCheckBox31.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox31.TabIndex = 31
        Me.TCCheckBox31.Tag = "31"
        Me.TCCheckBox31.Text = "TC31"
        Me.TCCheckBox31.UseVisualStyleBackColor = True
        '
        'TCCheckBox32
        '
        Me.TCCheckBox32.AutoSize = True
        Me.TCCheckBox32.Location = New System.Drawing.Point(193, 213)
        Me.TCCheckBox32.Name = "TCCheckBox32"
        Me.TCCheckBox32.Size = New System.Drawing.Size(52, 17)
        Me.TCCheckBox32.TabIndex = 32
        Me.TCCheckBox32.Tag = "32"
        Me.TCCheckBox32.Text = "TC32"
        Me.TCCheckBox32.UseVisualStyleBackColor = True
        '
        'OvenThermocouples
        '
        Me.AcceptButton = Me.OkButton1
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(256, 275)
        Me.Controls.Add(Me.OkButton1)
        Me.Controls.Add(Me.TCCheckBox32)
        Me.Controls.Add(Me.TCCheckBox31)
        Me.Controls.Add(Me.TCCheckBox16)
        Me.Controls.Add(Me.TCCheckBox30)
        Me.Controls.Add(Me.TCCheckBox15)
        Me.Controls.Add(Me.TCCheckBox29)
        Me.Controls.Add(Me.TCCheckBox14)
        Me.Controls.Add(Me.TCCheckBox28)
        Me.Controls.Add(Me.TCCheckBox13)
        Me.Controls.Add(Me.TCCheckBox27)
        Me.Controls.Add(Me.TCCheckBox12)
        Me.Controls.Add(Me.TCCheckBox26)
        Me.Controls.Add(Me.TCCheckBox11)
        Me.Controls.Add(Me.TCCheckBox24)
        Me.Controls.Add(Me.TCCheckBox10)
        Me.Controls.Add(Me.TCCheckBox23)
        Me.Controls.Add(Me.TCCheckBox8)
        Me.Controls.Add(Me.TCCheckBox22)
        Me.Controls.Add(Me.TCCheckBox7)
        Me.Controls.Add(Me.TCCheckBox21)
        Me.Controls.Add(Me.TCCheckBox6)
        Me.Controls.Add(Me.TCCheckBox20)
        Me.Controls.Add(Me.TCCheckBox5)
        Me.Controls.Add(Me.TCCheckBox19)
        Me.Controls.Add(Me.TCCheckBox4)
        Me.Controls.Add(Me.TCCheckBox18)
        Me.Controls.Add(Me.TCCheckBox3)
        Me.Controls.Add(Me.TCCheckBox25)
        Me.Controls.Add(Me.TCCheckBox2)
        Me.Controls.Add(Me.TCCheckBox17)
        Me.Controls.Add(Me.TCCheckBox9)
        Me.Controls.Add(Me.TCCheckBox1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "OvenThermocouples"
        Me.Text = "Select TC/TCs"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TCCheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox9 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox10 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox11 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox12 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox13 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox14 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox7 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox15 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox8 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox16 As System.Windows.Forms.CheckBox
    Friend WithEvents OkButton1 As System.Windows.Forms.Button
    Friend WithEvents TCCheckBox17 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox25 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox18 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox19 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox20 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox21 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox22 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox23 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox24 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox26 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox27 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox28 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox29 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox30 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox31 As System.Windows.Forms.CheckBox
    Friend WithEvents TCCheckBox32 As System.Windows.Forms.CheckBox
End Class
