﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPartRecipeSetup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmPartRecipeSetup))
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend1 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.cbodelete = New System.Windows.Forms.Button()
        Me.lstavailablestations = New System.Windows.Forms.ListBox()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.lststations = New System.Windows.Forms.ListBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtpartnumber = New System.Windows.Forms.TextBox()
        Me.txtpartname = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.chkusepreheat = New System.Windows.Forms.CheckBox()
        Me.txtpreheattime = New System.Windows.Forms.TextBox()
        Me.txtpreheath = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtpreheat = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtpreheatl = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.btnupdatechart1 = New System.Windows.Forms.Button()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.cbo10 = New System.Windows.Forms.ComboBox()
        Me.cbo9 = New System.Windows.Forms.ComboBox()
        Me.cbo8 = New System.Windows.Forms.ComboBox()
        Me.cbo7 = New System.Windows.Forms.ComboBox()
        Me.cbo6 = New System.Windows.Forms.ComboBox()
        Me.cbo5 = New System.Windows.Forms.ComboBox()
        Me.cbo4 = New System.Windows.Forms.ComboBox()
        Me.cbo3 = New System.Windows.Forms.ComboBox()
        Me.cbo2 = New System.Windows.Forms.ComboBox()
        Me.cbo1 = New System.Windows.Forms.ComboBox()
        Me.txttimeh10 = New System.Windows.Forms.TextBox()
        Me.txttimel10 = New System.Windows.Forms.TextBox()
        Me.txttimeh9 = New System.Windows.Forms.TextBox()
        Me.txttimel9 = New System.Windows.Forms.TextBox()
        Me.txttimeh8 = New System.Windows.Forms.TextBox()
        Me.txttimel8 = New System.Windows.Forms.TextBox()
        Me.txttimeh7 = New System.Windows.Forms.TextBox()
        Me.txttimel7 = New System.Windows.Forms.TextBox()
        Me.txttimeh6 = New System.Windows.Forms.TextBox()
        Me.txttimel6 = New System.Windows.Forms.TextBox()
        Me.txttimeh5 = New System.Windows.Forms.TextBox()
        Me.txttime10 = New System.Windows.Forms.TextBox()
        Me.txttimel5 = New System.Windows.Forms.TextBox()
        Me.txttime9 = New System.Windows.Forms.TextBox()
        Me.txttimeh4 = New System.Windows.Forms.TextBox()
        Me.txttime8 = New System.Windows.Forms.TextBox()
        Me.txttimel4 = New System.Windows.Forms.TextBox()
        Me.txttime7 = New System.Windows.Forms.TextBox()
        Me.txttimeh3 = New System.Windows.Forms.TextBox()
        Me.txttime6 = New System.Windows.Forms.TextBox()
        Me.txttimel3 = New System.Windows.Forms.TextBox()
        Me.txtsph10 = New System.Windows.Forms.TextBox()
        Me.txttime5 = New System.Windows.Forms.TextBox()
        Me.txtsph9 = New System.Windows.Forms.TextBox()
        Me.txttimeh2 = New System.Windows.Forms.TextBox()
        Me.txtsph8 = New System.Windows.Forms.TextBox()
        Me.txttime4 = New System.Windows.Forms.TextBox()
        Me.txtsph7 = New System.Windows.Forms.TextBox()
        Me.txttimel2 = New System.Windows.Forms.TextBox()
        Me.txtsph6 = New System.Windows.Forms.TextBox()
        Me.txttime3 = New System.Windows.Forms.TextBox()
        Me.txtspl10 = New System.Windows.Forms.TextBox()
        Me.txtsph5 = New System.Windows.Forms.TextBox()
        Me.txtspl9 = New System.Windows.Forms.TextBox()
        Me.txttimeh1 = New System.Windows.Forms.TextBox()
        Me.txtspl8 = New System.Windows.Forms.TextBox()
        Me.txtsph4 = New System.Windows.Forms.TextBox()
        Me.txtspl7 = New System.Windows.Forms.TextBox()
        Me.txttime2 = New System.Windows.Forms.TextBox()
        Me.txtspl6 = New System.Windows.Forms.TextBox()
        Me.txtsph3 = New System.Windows.Forms.TextBox()
        Me.txtsp10 = New System.Windows.Forms.TextBox()
        Me.txtspl5 = New System.Windows.Forms.TextBox()
        Me.txtsp9 = New System.Windows.Forms.TextBox()
        Me.txttimel1 = New System.Windows.Forms.TextBox()
        Me.txtsp8 = New System.Windows.Forms.TextBox()
        Me.txtspl4 = New System.Windows.Forms.TextBox()
        Me.txtsp7 = New System.Windows.Forms.TextBox()
        Me.txtsph2 = New System.Windows.Forms.TextBox()
        Me.txtsp6 = New System.Windows.Forms.TextBox()
        Me.txtspl3 = New System.Windows.Forms.TextBox()
        Me.txtsp5 = New System.Windows.Forms.TextBox()
        Me.txttime1 = New System.Windows.Forms.TextBox()
        Me.txtsp4 = New System.Windows.Forms.TextBox()
        Me.txtspl2 = New System.Windows.Forms.TextBox()
        Me.txtsp3 = New System.Windows.Forms.TextBox()
        Me.txtsph1 = New System.Windows.Forms.TextBox()
        Me.txtsp2 = New System.Windows.Forms.TextBox()
        Me.txtspl1 = New System.Windows.Forms.TextBox()
        Me.txtsp1 = New System.Windows.Forms.TextBox()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Lbl106 = New System.Windows.Forms.Label()
        Me.Lbl96 = New System.Windows.Forms.Label()
        Me.Lbl86 = New System.Windows.Forms.Label()
        Me.Lbl76 = New System.Windows.Forms.Label()
        Me.Lbl66 = New System.Windows.Forms.Label()
        Me.Lbl56 = New System.Windows.Forms.Label()
        Me.Lbl46 = New System.Windows.Forms.Label()
        Me.Lbl36 = New System.Windows.Forms.Label()
        Me.Lbl26 = New System.Windows.Forms.Label()
        Me.Lbl105 = New System.Windows.Forms.Label()
        Me.Lbl95 = New System.Windows.Forms.Label()
        Me.Lbl85 = New System.Windows.Forms.Label()
        Me.Lbl75 = New System.Windows.Forms.Label()
        Me.Lbl16 = New System.Windows.Forms.Label()
        Me.Lbl65 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Lbl55 = New System.Windows.Forms.Label()
        Me.Lbl45 = New System.Windows.Forms.Label()
        Me.Lbl35 = New System.Windows.Forms.Label()
        Me.Lbl25 = New System.Windows.Forms.Label()
        Me.Lbl104 = New System.Windows.Forms.Label()
        Me.Lbl94 = New System.Windows.Forms.Label()
        Me.Lbl84 = New System.Windows.Forms.Label()
        Me.Lbl74 = New System.Windows.Forms.Label()
        Me.lblsegment = New System.Windows.Forms.Label()
        Me.Lbl64 = New System.Windows.Forms.Label()
        Me.Lbl15 = New System.Windows.Forms.Label()
        Me.Lbl54 = New System.Windows.Forms.Label()
        Me.Lbl44 = New System.Windows.Forms.Label()
        Me.Lbl34 = New System.Windows.Forms.Label()
        Me.Lbl101 = New System.Windows.Forms.Label()
        Me.Lbl91 = New System.Windows.Forms.Label()
        Me.Lbl81 = New System.Windows.Forms.Label()
        Me.Lbl71 = New System.Windows.Forms.Label()
        Me.Lbl24 = New System.Windows.Forms.Label()
        Me.Lbl61 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Lbl102 = New System.Windows.Forms.Label()
        Me.Lbl92 = New System.Windows.Forms.Label()
        Me.Lbl82 = New System.Windows.Forms.Label()
        Me.Lbl51 = New System.Windows.Forms.Label()
        Me.Lbl72 = New System.Windows.Forms.Label()
        Me.Lbl41 = New System.Windows.Forms.Label()
        Me.Lbl62 = New System.Windows.Forms.Label()
        Me.Lbl103 = New System.Windows.Forms.Label()
        Me.Lbl31 = New System.Windows.Forms.Label()
        Me.Lbl93 = New System.Windows.Forms.Label()
        Me.Lbl52 = New System.Windows.Forms.Label()
        Me.Lbl83 = New System.Windows.Forms.Label()
        Me.Lbl21 = New System.Windows.Forms.Label()
        Me.Lbl73 = New System.Windows.Forms.Label()
        Me.Lbl42 = New System.Windows.Forms.Label()
        Me.Lbl63 = New System.Windows.Forms.Label()
        Me.Lbl32 = New System.Windows.Forms.Label()
        Me.Lbl53 = New System.Windows.Forms.Label()
        Me.Lbl14 = New System.Windows.Forms.Label()
        Me.Lbl43 = New System.Windows.Forms.Label()
        Me.Lbl22 = New System.Windows.Forms.Label()
        Me.Lbl33 = New System.Windows.Forms.Label()
        Me.lbl11 = New System.Windows.Forms.Label()
        Me.Lbl23 = New System.Windows.Forms.Label()
        Me.Lbl12 = New System.Windows.Forms.Label()
        Me.Lbl13 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtdb2 = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txthys2 = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.txtderiv2 = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtreset2 = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtpb2 = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtdb1 = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txthys1 = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtderiv1 = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtreset1 = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtpb1 = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateInitialCureChartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateSecondaryPostCureChartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StationInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(12, 27)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(719, 699)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(711, 673)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "General Part Information"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.cbodelete)
        Me.GroupBox2.Controls.Add(Me.lstavailablestations)
        Me.GroupBox2.Controls.Add(Me.btnadd)
        Me.GroupBox2.Controls.Add(Me.lststations)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 90)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(319, 310)
        Me.GroupBox2.TabIndex = 10
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Stations to Apply Part Recipe"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(16, 29)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(125, 13)
        Me.Label25.TabIndex = 5
        Me.Label25.Text = "Available Curing Devices"
        '
        'cbodelete
        '
        Me.cbodelete.Location = New System.Drawing.Point(230, 276)
        Me.cbodelete.Name = "cbodelete"
        Me.cbodelete.Size = New System.Drawing.Size(74, 24)
        Me.cbodelete.TabIndex = 8
        Me.cbodelete.Text = "Delete"
        Me.cbodelete.UseVisualStyleBackColor = True
        '
        'lstavailablestations
        '
        Me.lstavailablestations.FormattingEnabled = True
        Me.lstavailablestations.Location = New System.Drawing.Point(4, 45)
        Me.lstavailablestations.Name = "lstavailablestations"
        Me.lstavailablestations.ScrollAlwaysVisible = True
        Me.lstavailablestations.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstavailablestations.Size = New System.Drawing.Size(147, 225)
        Me.lstavailablestations.TabIndex = 4
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(157, 276)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(67, 24)
        Me.btnadd.TabIndex = 9
        Me.btnadd.Text = "Add"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'lststations
        '
        Me.lststations.FormattingEnabled = True
        Me.lststations.Location = New System.Drawing.Point(157, 45)
        Me.lststations.Name = "lststations"
        Me.lststations.ScrollAlwaysVisible = True
        Me.lststations.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lststations.Size = New System.Drawing.Size(147, 225)
        Me.lststations.TabIndex = 6
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(177, 29)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(112, 13)
        Me.Label26.TabIndex = 7
        Me.Label26.Text = "Cure Devices to Apply"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtpartnumber)
        Me.GroupBox1.Controls.Add(Me.txtpartname)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(279, 78)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Part Information"
        '
        'txtpartnumber
        '
        Me.txtpartnumber.Location = New System.Drawing.Point(96, 22)
        Me.txtpartnumber.Name = "txtpartnumber"
        Me.txtpartnumber.Size = New System.Drawing.Size(171, 20)
        Me.txtpartnumber.TabIndex = 1
        '
        'txtpartname
        '
        Me.txtpartname.Location = New System.Drawing.Point(95, 49)
        Me.txtpartname.Name = "txtpartname"
        Me.txtpartname.Size = New System.Drawing.Size(171, 20)
        Me.txtpartname.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Part Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Part Number:"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label9)
        Me.TabPage4.Controls.Add(Me.chkusepreheat)
        Me.TabPage4.Controls.Add(Me.txtpreheattime)
        Me.TabPage4.Controls.Add(Me.txtpreheath)
        Me.TabPage4.Controls.Add(Me.Label14)
        Me.TabPage4.Controls.Add(Me.Label15)
        Me.TabPage4.Controls.Add(Me.txtpreheat)
        Me.TabPage4.Controls.Add(Me.Label6)
        Me.TabPage4.Controls.Add(Me.Label8)
        Me.TabPage4.Controls.Add(Me.txtpreheatl)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(711, 673)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Preheat"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 15)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(293, 52)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "Enter preheat information. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Low preheat temperature must be less than nominal." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) &
    "High preheat temperature must be more than nominal." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Decimal values will be roun" &
    "ded to the nearest whole number."
        '
        'chkusepreheat
        '
        Me.chkusepreheat.AutoSize = True
        Me.chkusepreheat.Checked = True
        Me.chkusepreheat.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkusepreheat.Enabled = False
        Me.chkusepreheat.Location = New System.Drawing.Point(9, 80)
        Me.chkusepreheat.Name = "chkusepreheat"
        Me.chkusepreheat.Size = New System.Drawing.Size(85, 17)
        Me.chkusepreheat.TabIndex = 1
        Me.chkusepreheat.Text = "Use Preheat"
        Me.ToolTip1.SetToolTip(Me.chkusepreheat, "Check preheat if a preheat is necessary before injection.")
        Me.chkusepreheat.UseVisualStyleBackColor = True
        '
        'txtpreheattime
        '
        Me.txtpreheattime.Location = New System.Drawing.Point(145, 179)
        Me.txtpreheattime.Name = "txtpreheattime"
        Me.txtpreheattime.Size = New System.Drawing.Size(115, 20)
        Me.txtpreheattime.TabIndex = 4
        Me.txtpreheattime.Text = "1"
        Me.ToolTip1.SetToolTip(Me.txtpreheattime, "Minimum preheat soak time between low and high preheat tempeatures. Injection may" &
        " not be started until part has soaked for this time.")
        '
        'txtpreheath
        '
        Me.txtpreheath.Location = New System.Drawing.Point(127, 153)
        Me.txtpreheath.Name = "txtpreheath"
        Me.txtpreheath.Size = New System.Drawing.Size(133, 20)
        Me.txtpreheath.TabIndex = 3
        Me.txtpreheath.Tag = ""
        Me.txtpreheath.Text = "135"
        Me.ToolTip1.SetToolTip(Me.txtpreheath, "Highest allowable preheat temperature. This must be higher than nominal preheat t" &
        "emperature.")
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 104)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(133, 13)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Nominal Preheat Temp. (F)"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(6, 182)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(139, 13)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Minimum Preheat Time (min)"
        '
        'txtpreheat
        '
        Me.txtpreheat.Location = New System.Drawing.Point(145, 101)
        Me.txtpreheat.Name = "txtpreheat"
        Me.txtpreheat.Size = New System.Drawing.Size(115, 20)
        Me.txtpreheat.TabIndex = 1
        Me.txtpreheat.Text = "115"
        Me.ToolTip1.SetToolTip(Me.txtpreheat, "Nominal temperature for preheat.")
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 156)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(114, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "High Preheat Temp.(F)"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 130)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(115, 13)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Low Preheat Temp. (F)"
        '
        'txtpreheatl
        '
        Me.txtpreheatl.Location = New System.Drawing.Point(127, 127)
        Me.txtpreheatl.Name = "txtpreheatl"
        Me.txtpreheatl.Size = New System.Drawing.Size(133, 20)
        Me.txtpreheatl.TabIndex = 2
        Me.txtpreheatl.Text = "125"
        Me.ToolTip1.SetToolTip(Me.txtpreheatl, "Low preheat temperature. This must be lower or equal to nominal preheat temperatu" &
        "re.")
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label49)
        Me.TabPage2.Controls.Add(Me.Label48)
        Me.TabPage2.Controls.Add(Me.Label47)
        Me.TabPage2.Controls.Add(Me.Label46)
        Me.TabPage2.Controls.Add(Me.Label45)
        Me.TabPage2.Controls.Add(Me.Label44)
        Me.TabPage2.Controls.Add(Me.Label43)
        Me.TabPage2.Controls.Add(Me.Label42)
        Me.TabPage2.Controls.Add(Me.Label41)
        Me.TabPage2.Controls.Add(Me.Label40)
        Me.TabPage2.Controls.Add(Me.Label39)
        Me.TabPage2.Controls.Add(Me.btnupdatechart1)
        Me.TabPage2.Controls.Add(Me.CheckBox10)
        Me.TabPage2.Controls.Add(Me.CheckBox9)
        Me.TabPage2.Controls.Add(Me.CheckBox8)
        Me.TabPage2.Controls.Add(Me.CheckBox7)
        Me.TabPage2.Controls.Add(Me.CheckBox6)
        Me.TabPage2.Controls.Add(Me.CheckBox5)
        Me.TabPage2.Controls.Add(Me.CheckBox4)
        Me.TabPage2.Controls.Add(Me.CheckBox3)
        Me.TabPage2.Controls.Add(Me.CheckBox2)
        Me.TabPage2.Controls.Add(Me.CheckBox1)
        Me.TabPage2.Controls.Add(Me.cbo10)
        Me.TabPage2.Controls.Add(Me.cbo9)
        Me.TabPage2.Controls.Add(Me.cbo8)
        Me.TabPage2.Controls.Add(Me.cbo7)
        Me.TabPage2.Controls.Add(Me.cbo6)
        Me.TabPage2.Controls.Add(Me.cbo5)
        Me.TabPage2.Controls.Add(Me.cbo4)
        Me.TabPage2.Controls.Add(Me.cbo3)
        Me.TabPage2.Controls.Add(Me.cbo2)
        Me.TabPage2.Controls.Add(Me.cbo1)
        Me.TabPage2.Controls.Add(Me.txttimeh10)
        Me.TabPage2.Controls.Add(Me.txttimel10)
        Me.TabPage2.Controls.Add(Me.txttimeh9)
        Me.TabPage2.Controls.Add(Me.txttimel9)
        Me.TabPage2.Controls.Add(Me.txttimeh8)
        Me.TabPage2.Controls.Add(Me.txttimel8)
        Me.TabPage2.Controls.Add(Me.txttimeh7)
        Me.TabPage2.Controls.Add(Me.txttimel7)
        Me.TabPage2.Controls.Add(Me.txttimeh6)
        Me.TabPage2.Controls.Add(Me.txttimel6)
        Me.TabPage2.Controls.Add(Me.txttimeh5)
        Me.TabPage2.Controls.Add(Me.txttime10)
        Me.TabPage2.Controls.Add(Me.txttimel5)
        Me.TabPage2.Controls.Add(Me.txttime9)
        Me.TabPage2.Controls.Add(Me.txttimeh4)
        Me.TabPage2.Controls.Add(Me.txttime8)
        Me.TabPage2.Controls.Add(Me.txttimel4)
        Me.TabPage2.Controls.Add(Me.txttime7)
        Me.TabPage2.Controls.Add(Me.txttimeh3)
        Me.TabPage2.Controls.Add(Me.txttime6)
        Me.TabPage2.Controls.Add(Me.txttimel3)
        Me.TabPage2.Controls.Add(Me.txtsph10)
        Me.TabPage2.Controls.Add(Me.txttime5)
        Me.TabPage2.Controls.Add(Me.txtsph9)
        Me.TabPage2.Controls.Add(Me.txttimeh2)
        Me.TabPage2.Controls.Add(Me.txtsph8)
        Me.TabPage2.Controls.Add(Me.txttime4)
        Me.TabPage2.Controls.Add(Me.txtsph7)
        Me.TabPage2.Controls.Add(Me.txttimel2)
        Me.TabPage2.Controls.Add(Me.txtsph6)
        Me.TabPage2.Controls.Add(Me.txttime3)
        Me.TabPage2.Controls.Add(Me.txtspl10)
        Me.TabPage2.Controls.Add(Me.txtsph5)
        Me.TabPage2.Controls.Add(Me.txtspl9)
        Me.TabPage2.Controls.Add(Me.txttimeh1)
        Me.TabPage2.Controls.Add(Me.txtspl8)
        Me.TabPage2.Controls.Add(Me.txtsph4)
        Me.TabPage2.Controls.Add(Me.txtspl7)
        Me.TabPage2.Controls.Add(Me.txttime2)
        Me.TabPage2.Controls.Add(Me.txtspl6)
        Me.TabPage2.Controls.Add(Me.txtsph3)
        Me.TabPage2.Controls.Add(Me.txtsp10)
        Me.TabPage2.Controls.Add(Me.txtspl5)
        Me.TabPage2.Controls.Add(Me.txtsp9)
        Me.TabPage2.Controls.Add(Me.txttimel1)
        Me.TabPage2.Controls.Add(Me.txtsp8)
        Me.TabPage2.Controls.Add(Me.txtspl4)
        Me.TabPage2.Controls.Add(Me.txtsp7)
        Me.TabPage2.Controls.Add(Me.txtsph2)
        Me.TabPage2.Controls.Add(Me.txtsp6)
        Me.TabPage2.Controls.Add(Me.txtspl3)
        Me.TabPage2.Controls.Add(Me.txtsp5)
        Me.TabPage2.Controls.Add(Me.txttime1)
        Me.TabPage2.Controls.Add(Me.txtsp4)
        Me.TabPage2.Controls.Add(Me.txtspl2)
        Me.TabPage2.Controls.Add(Me.txtsp3)
        Me.TabPage2.Controls.Add(Me.txtsph1)
        Me.TabPage2.Controls.Add(Me.txtsp2)
        Me.TabPage2.Controls.Add(Me.txtspl1)
        Me.TabPage2.Controls.Add(Me.txtsp1)
        Me.TabPage2.Controls.Add(Me.Chart1)
        Me.TabPage2.Controls.Add(Me.Lbl106)
        Me.TabPage2.Controls.Add(Me.Lbl96)
        Me.TabPage2.Controls.Add(Me.Lbl86)
        Me.TabPage2.Controls.Add(Me.Lbl76)
        Me.TabPage2.Controls.Add(Me.Lbl66)
        Me.TabPage2.Controls.Add(Me.Lbl56)
        Me.TabPage2.Controls.Add(Me.Lbl46)
        Me.TabPage2.Controls.Add(Me.Lbl36)
        Me.TabPage2.Controls.Add(Me.Lbl26)
        Me.TabPage2.Controls.Add(Me.Lbl105)
        Me.TabPage2.Controls.Add(Me.Lbl95)
        Me.TabPage2.Controls.Add(Me.Lbl85)
        Me.TabPage2.Controls.Add(Me.Lbl75)
        Me.TabPage2.Controls.Add(Me.Lbl16)
        Me.TabPage2.Controls.Add(Me.Lbl65)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.Lbl55)
        Me.TabPage2.Controls.Add(Me.Lbl45)
        Me.TabPage2.Controls.Add(Me.Lbl35)
        Me.TabPage2.Controls.Add(Me.Lbl25)
        Me.TabPage2.Controls.Add(Me.Lbl104)
        Me.TabPage2.Controls.Add(Me.Lbl94)
        Me.TabPage2.Controls.Add(Me.Lbl84)
        Me.TabPage2.Controls.Add(Me.Lbl74)
        Me.TabPage2.Controls.Add(Me.lblsegment)
        Me.TabPage2.Controls.Add(Me.Lbl64)
        Me.TabPage2.Controls.Add(Me.Lbl15)
        Me.TabPage2.Controls.Add(Me.Lbl54)
        Me.TabPage2.Controls.Add(Me.Lbl44)
        Me.TabPage2.Controls.Add(Me.Lbl34)
        Me.TabPage2.Controls.Add(Me.Lbl101)
        Me.TabPage2.Controls.Add(Me.Lbl91)
        Me.TabPage2.Controls.Add(Me.Lbl81)
        Me.TabPage2.Controls.Add(Me.Lbl71)
        Me.TabPage2.Controls.Add(Me.Lbl24)
        Me.TabPage2.Controls.Add(Me.Lbl61)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.Lbl102)
        Me.TabPage2.Controls.Add(Me.Lbl92)
        Me.TabPage2.Controls.Add(Me.Lbl82)
        Me.TabPage2.Controls.Add(Me.Lbl51)
        Me.TabPage2.Controls.Add(Me.Lbl72)
        Me.TabPage2.Controls.Add(Me.Lbl41)
        Me.TabPage2.Controls.Add(Me.Lbl62)
        Me.TabPage2.Controls.Add(Me.Lbl103)
        Me.TabPage2.Controls.Add(Me.Lbl31)
        Me.TabPage2.Controls.Add(Me.Lbl93)
        Me.TabPage2.Controls.Add(Me.Lbl52)
        Me.TabPage2.Controls.Add(Me.Lbl83)
        Me.TabPage2.Controls.Add(Me.Lbl21)
        Me.TabPage2.Controls.Add(Me.Lbl73)
        Me.TabPage2.Controls.Add(Me.Lbl42)
        Me.TabPage2.Controls.Add(Me.Lbl63)
        Me.TabPage2.Controls.Add(Me.Lbl32)
        Me.TabPage2.Controls.Add(Me.Lbl53)
        Me.TabPage2.Controls.Add(Me.Lbl14)
        Me.TabPage2.Controls.Add(Me.Lbl43)
        Me.TabPage2.Controls.Add(Me.Lbl22)
        Me.TabPage2.Controls.Add(Me.Lbl33)
        Me.TabPage2.Controls.Add(Me.lbl11)
        Me.TabPage2.Controls.Add(Me.Lbl23)
        Me.TabPage2.Controls.Add(Me.Lbl12)
        Me.TabPage2.Controls.Add(Me.Lbl13)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(711, 673)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Cure Cycle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(6, 11)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(379, 13)
        Me.Label49.TabIndex = 204
        Me.Label49.Text = "Enter the cure cycle for the part. This should be entered to customer/FDI spec."
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(54, 646)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(19, 13)
        Me.Label48.TabIndex = 203
        Me.Label48.Text = "10"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(62, 608)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(13, 13)
        Me.Label47.TabIndex = 202
        Me.Label47.Text = "9"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(60, 569)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(13, 13)
        Me.Label46.TabIndex = 201
        Me.Label46.Text = "8"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(62, 530)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(13, 13)
        Me.Label45.TabIndex = 200
        Me.Label45.Text = "7"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(62, 491)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(13, 13)
        Me.Label44.TabIndex = 199
        Me.Label44.Text = "6"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(62, 451)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(13, 13)
        Me.Label43.TabIndex = 198
        Me.Label43.Text = "5"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(62, 413)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(13, 13)
        Me.Label42.TabIndex = 197
        Me.Label42.Text = "4"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(62, 373)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(13, 13)
        Me.Label41.TabIndex = 196
        Me.Label41.Text = "3"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(62, 335)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(13, 13)
        Me.Label40.TabIndex = 195
        Me.Label40.Text = "2"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(62, 295)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(13, 13)
        Me.Label39.TabIndex = 194
        Me.Label39.Text = "1"
        '
        'btnupdatechart1
        '
        Me.btnupdatechart1.Location = New System.Drawing.Point(639, 252)
        Me.btnupdatechart1.Name = "btnupdatechart1"
        Me.btnupdatechart1.Size = New System.Drawing.Size(63, 21)
        Me.btnupdatechart1.TabIndex = 193
        Me.btnupdatechart1.Text = "Update"
        Me.btnupdatechart1.UseVisualStyleBackColor = True
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Location = New System.Drawing.Point(30, 647)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox10.TabIndex = 185
        Me.ToolTip1.SetToolTip(Me.CheckBox10, "Check to activate segment.")
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(30, 608)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox9.TabIndex = 177
        Me.ToolTip1.SetToolTip(Me.CheckBox9, "Check to activate segment.")
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Location = New System.Drawing.Point(28, 569)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox8.TabIndex = 169
        Me.ToolTip1.SetToolTip(Me.CheckBox8, "Check to activate segment.")
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Location = New System.Drawing.Point(30, 530)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox7.TabIndex = 161
        Me.ToolTip1.SetToolTip(Me.CheckBox7, "Check to activate segment.")
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(30, 491)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox6.TabIndex = 153
        Me.ToolTip1.SetToolTip(Me.CheckBox6, "Check to activate segment.")
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Location = New System.Drawing.Point(30, 452)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox5.TabIndex = 146
        Me.ToolTip1.SetToolTip(Me.CheckBox5, "Check to activate segment.")
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(30, 413)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox4.TabIndex = 138
        Me.ToolTip1.SetToolTip(Me.CheckBox4, "Check to activate segment.")
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(30, 374)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox3.TabIndex = 130
        Me.ToolTip1.SetToolTip(Me.CheckBox3, "Check to activate segment.")
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(30, 335)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox2.TabIndex = 122
        Me.ToolTip1.SetToolTip(Me.CheckBox2, "Check to activate segment.")
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(30, 296)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox1.TabIndex = 114
        Me.ToolTip1.SetToolTip(Me.CheckBox1, "Check to activate segment.")
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'cbo10
        '
        Me.cbo10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo10.Enabled = False
        Me.cbo10.FormattingEnabled = True
        Me.cbo10.Location = New System.Drawing.Point(79, 643)
        Me.cbo10.Name = "cbo10"
        Me.cbo10.Size = New System.Drawing.Size(100, 21)
        Me.cbo10.TabIndex = 186
        Me.ToolTip1.SetToolTip(Me.cbo10, resources.GetString("cbo10.ToolTip"))
        '
        'cbo9
        '
        Me.cbo9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo9.Enabled = False
        Me.cbo9.FormattingEnabled = True
        Me.cbo9.Location = New System.Drawing.Point(81, 604)
        Me.cbo9.Name = "cbo9"
        Me.cbo9.Size = New System.Drawing.Size(98, 21)
        Me.cbo9.TabIndex = 178
        Me.ToolTip1.SetToolTip(Me.cbo9, resources.GetString("cbo9.ToolTip"))
        '
        'cbo8
        '
        Me.cbo8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo8.Enabled = False
        Me.cbo8.FormattingEnabled = True
        Me.cbo8.Location = New System.Drawing.Point(79, 565)
        Me.cbo8.Name = "cbo8"
        Me.cbo8.Size = New System.Drawing.Size(98, 21)
        Me.cbo8.TabIndex = 170
        Me.ToolTip1.SetToolTip(Me.cbo8, resources.GetString("cbo8.ToolTip"))
        '
        'cbo7
        '
        Me.cbo7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo7.Enabled = False
        Me.cbo7.FormattingEnabled = True
        Me.cbo7.Location = New System.Drawing.Point(81, 526)
        Me.cbo7.Name = "cbo7"
        Me.cbo7.Size = New System.Drawing.Size(98, 21)
        Me.cbo7.TabIndex = 162
        Me.ToolTip1.SetToolTip(Me.cbo7, resources.GetString("cbo7.ToolTip"))
        '
        'cbo6
        '
        Me.cbo6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo6.Enabled = False
        Me.cbo6.FormattingEnabled = True
        Me.cbo6.Location = New System.Drawing.Point(81, 487)
        Me.cbo6.Name = "cbo6"
        Me.cbo6.Size = New System.Drawing.Size(98, 21)
        Me.cbo6.TabIndex = 154
        Me.ToolTip1.SetToolTip(Me.cbo6, resources.GetString("cbo6.ToolTip"))
        '
        'cbo5
        '
        Me.cbo5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo5.Enabled = False
        Me.cbo5.FormattingEnabled = True
        Me.cbo5.Location = New System.Drawing.Point(81, 448)
        Me.cbo5.Name = "cbo5"
        Me.cbo5.Size = New System.Drawing.Size(98, 21)
        Me.cbo5.TabIndex = 106
        Me.ToolTip1.SetToolTip(Me.cbo5, resources.GetString("cbo5.ToolTip"))
        '
        'cbo4
        '
        Me.cbo4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo4.Enabled = False
        Me.cbo4.FormattingEnabled = True
        Me.cbo4.Location = New System.Drawing.Point(81, 409)
        Me.cbo4.Name = "cbo4"
        Me.cbo4.Size = New System.Drawing.Size(98, 21)
        Me.cbo4.TabIndex = 139
        Me.ToolTip1.SetToolTip(Me.cbo4, resources.GetString("cbo4.ToolTip"))
        '
        'cbo3
        '
        Me.cbo3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo3.Enabled = False
        Me.cbo3.FormattingEnabled = True
        Me.cbo3.Location = New System.Drawing.Point(81, 370)
        Me.cbo3.Name = "cbo3"
        Me.cbo3.Size = New System.Drawing.Size(98, 21)
        Me.cbo3.TabIndex = 131
        Me.ToolTip1.SetToolTip(Me.cbo3, resources.GetString("cbo3.ToolTip"))
        '
        'cbo2
        '
        Me.cbo2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo2.Enabled = False
        Me.cbo2.FormattingEnabled = True
        Me.cbo2.Location = New System.Drawing.Point(81, 331)
        Me.cbo2.Name = "cbo2"
        Me.cbo2.Size = New System.Drawing.Size(98, 21)
        Me.cbo2.TabIndex = 123
        Me.ToolTip1.SetToolTip(Me.cbo2, resources.GetString("cbo2.ToolTip"))
        '
        'cbo1
        '
        Me.cbo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo1.Enabled = False
        Me.cbo1.FormattingEnabled = True
        Me.cbo1.Location = New System.Drawing.Point(81, 292)
        Me.cbo1.Name = "cbo1"
        Me.cbo1.Size = New System.Drawing.Size(98, 21)
        Me.cbo1.TabIndex = 115
        Me.ToolTip1.SetToolTip(Me.cbo1, resources.GetString("cbo1.ToolTip"))
        '
        'txttimeh10
        '
        Me.txttimeh10.Enabled = False
        Me.txttimeh10.Location = New System.Drawing.Point(616, 644)
        Me.txttimeh10.Name = "txttimeh10"
        Me.txttimeh10.Size = New System.Drawing.Size(65, 20)
        Me.txttimeh10.TabIndex = 192
        '
        'txttimel10
        '
        Me.txttimel10.Enabled = False
        Me.txttimel10.Location = New System.Drawing.Point(542, 644)
        Me.txttimel10.Name = "txttimel10"
        Me.txttimel10.Size = New System.Drawing.Size(65, 20)
        Me.txttimel10.TabIndex = 191
        '
        'txttimeh9
        '
        Me.txttimeh9.Enabled = False
        Me.txttimeh9.Location = New System.Drawing.Point(616, 605)
        Me.txttimeh9.Name = "txttimeh9"
        Me.txttimeh9.Size = New System.Drawing.Size(65, 20)
        Me.txttimeh9.TabIndex = 184
        '
        'txttimel9
        '
        Me.txttimel9.Enabled = False
        Me.txttimel9.Location = New System.Drawing.Point(542, 605)
        Me.txttimel9.Name = "txttimel9"
        Me.txttimel9.Size = New System.Drawing.Size(65, 20)
        Me.txttimel9.TabIndex = 183
        '
        'txttimeh8
        '
        Me.txttimeh8.Enabled = False
        Me.txttimeh8.Location = New System.Drawing.Point(614, 566)
        Me.txttimeh8.Name = "txttimeh8"
        Me.txttimeh8.Size = New System.Drawing.Size(65, 20)
        Me.txttimeh8.TabIndex = 176
        '
        'txttimel8
        '
        Me.txttimel8.Enabled = False
        Me.txttimel8.Location = New System.Drawing.Point(540, 566)
        Me.txttimel8.Name = "txttimel8"
        Me.txttimel8.Size = New System.Drawing.Size(65, 20)
        Me.txttimel8.TabIndex = 175
        '
        'txttimeh7
        '
        Me.txttimeh7.Enabled = False
        Me.txttimeh7.Location = New System.Drawing.Point(616, 527)
        Me.txttimeh7.Name = "txttimeh7"
        Me.txttimeh7.Size = New System.Drawing.Size(65, 20)
        Me.txttimeh7.TabIndex = 168
        '
        'txttimel7
        '
        Me.txttimel7.Enabled = False
        Me.txttimel7.Location = New System.Drawing.Point(542, 527)
        Me.txttimel7.Name = "txttimel7"
        Me.txttimel7.Size = New System.Drawing.Size(65, 20)
        Me.txttimel7.TabIndex = 167
        '
        'txttimeh6
        '
        Me.txttimeh6.Enabled = False
        Me.txttimeh6.Location = New System.Drawing.Point(616, 488)
        Me.txttimeh6.Name = "txttimeh6"
        Me.txttimeh6.Size = New System.Drawing.Size(65, 20)
        Me.txttimeh6.TabIndex = 160
        '
        'txttimel6
        '
        Me.txttimel6.Enabled = False
        Me.txttimel6.Location = New System.Drawing.Point(542, 488)
        Me.txttimel6.Name = "txttimel6"
        Me.txttimel6.Size = New System.Drawing.Size(65, 20)
        Me.txttimel6.TabIndex = 159
        '
        'txttimeh5
        '
        Me.txttimeh5.Enabled = False
        Me.txttimeh5.Location = New System.Drawing.Point(616, 449)
        Me.txttimeh5.Name = "txttimeh5"
        Me.txttimeh5.Size = New System.Drawing.Size(65, 20)
        Me.txttimeh5.TabIndex = 152
        '
        'txttime10
        '
        Me.txttime10.Enabled = False
        Me.txttime10.Location = New System.Drawing.Point(481, 644)
        Me.txttime10.Name = "txttime10"
        Me.txttime10.Size = New System.Drawing.Size(52, 20)
        Me.txttime10.TabIndex = 190
        '
        'txttimel5
        '
        Me.txttimel5.Enabled = False
        Me.txttimel5.Location = New System.Drawing.Point(542, 449)
        Me.txttimel5.Name = "txttimel5"
        Me.txttimel5.Size = New System.Drawing.Size(65, 20)
        Me.txttimel5.TabIndex = 151
        '
        'txttime9
        '
        Me.txttime9.Enabled = False
        Me.txttime9.Location = New System.Drawing.Point(481, 605)
        Me.txttime9.Name = "txttime9"
        Me.txttime9.Size = New System.Drawing.Size(52, 20)
        Me.txttime9.TabIndex = 182
        '
        'txttimeh4
        '
        Me.txttimeh4.Enabled = False
        Me.txttimeh4.Location = New System.Drawing.Point(616, 410)
        Me.txttimeh4.Name = "txttimeh4"
        Me.txttimeh4.Size = New System.Drawing.Size(65, 20)
        Me.txttimeh4.TabIndex = 145
        '
        'txttime8
        '
        Me.txttime8.Enabled = False
        Me.txttime8.Location = New System.Drawing.Point(479, 566)
        Me.txttime8.Name = "txttime8"
        Me.txttime8.Size = New System.Drawing.Size(52, 20)
        Me.txttime8.TabIndex = 174
        '
        'txttimel4
        '
        Me.txttimel4.Enabled = False
        Me.txttimel4.Location = New System.Drawing.Point(542, 410)
        Me.txttimel4.Name = "txttimel4"
        Me.txttimel4.Size = New System.Drawing.Size(65, 20)
        Me.txttimel4.TabIndex = 144
        '
        'txttime7
        '
        Me.txttime7.Enabled = False
        Me.txttime7.Location = New System.Drawing.Point(481, 527)
        Me.txttime7.Name = "txttime7"
        Me.txttime7.Size = New System.Drawing.Size(52, 20)
        Me.txttime7.TabIndex = 166
        '
        'txttimeh3
        '
        Me.txttimeh3.Enabled = False
        Me.txttimeh3.Location = New System.Drawing.Point(616, 371)
        Me.txttimeh3.Name = "txttimeh3"
        Me.txttimeh3.Size = New System.Drawing.Size(65, 20)
        Me.txttimeh3.TabIndex = 137
        '
        'txttime6
        '
        Me.txttime6.Enabled = False
        Me.txttime6.Location = New System.Drawing.Point(481, 488)
        Me.txttime6.Name = "txttime6"
        Me.txttime6.Size = New System.Drawing.Size(52, 20)
        Me.txttime6.TabIndex = 158
        '
        'txttimel3
        '
        Me.txttimel3.Enabled = False
        Me.txttimel3.Location = New System.Drawing.Point(542, 371)
        Me.txttimel3.Name = "txttimel3"
        Me.txttimel3.Size = New System.Drawing.Size(65, 20)
        Me.txttimel3.TabIndex = 136
        '
        'txtsph10
        '
        Me.txtsph10.Enabled = False
        Me.txtsph10.Location = New System.Drawing.Point(386, 644)
        Me.txtsph10.Name = "txtsph10"
        Me.txtsph10.Size = New System.Drawing.Size(86, 20)
        Me.txtsph10.TabIndex = 189
        '
        'txttime5
        '
        Me.txttime5.Enabled = False
        Me.txttime5.Location = New System.Drawing.Point(481, 449)
        Me.txttime5.Name = "txttime5"
        Me.txttime5.Size = New System.Drawing.Size(52, 20)
        Me.txttime5.TabIndex = 150
        '
        'txtsph9
        '
        Me.txtsph9.Enabled = False
        Me.txtsph9.Location = New System.Drawing.Point(386, 605)
        Me.txtsph9.Name = "txtsph9"
        Me.txtsph9.Size = New System.Drawing.Size(86, 20)
        Me.txtsph9.TabIndex = 181
        '
        'txttimeh2
        '
        Me.txttimeh2.Enabled = False
        Me.txttimeh2.Location = New System.Drawing.Point(616, 332)
        Me.txttimeh2.Name = "txttimeh2"
        Me.txttimeh2.Size = New System.Drawing.Size(65, 20)
        Me.txttimeh2.TabIndex = 129
        '
        'txtsph8
        '
        Me.txtsph8.Enabled = False
        Me.txtsph8.Location = New System.Drawing.Point(384, 566)
        Me.txtsph8.Name = "txtsph8"
        Me.txtsph8.Size = New System.Drawing.Size(86, 20)
        Me.txtsph8.TabIndex = 173
        '
        'txttime4
        '
        Me.txttime4.Enabled = False
        Me.txttime4.Location = New System.Drawing.Point(481, 410)
        Me.txttime4.Name = "txttime4"
        Me.txttime4.Size = New System.Drawing.Size(52, 20)
        Me.txttime4.TabIndex = 143
        '
        'txtsph7
        '
        Me.txtsph7.Enabled = False
        Me.txtsph7.Location = New System.Drawing.Point(386, 527)
        Me.txtsph7.Name = "txtsph7"
        Me.txtsph7.Size = New System.Drawing.Size(86, 20)
        Me.txtsph7.TabIndex = 165
        '
        'txttimel2
        '
        Me.txttimel2.Enabled = False
        Me.txttimel2.Location = New System.Drawing.Point(542, 332)
        Me.txttimel2.Name = "txttimel2"
        Me.txttimel2.Size = New System.Drawing.Size(65, 20)
        Me.txttimel2.TabIndex = 128
        '
        'txtsph6
        '
        Me.txtsph6.Enabled = False
        Me.txtsph6.Location = New System.Drawing.Point(386, 488)
        Me.txtsph6.Name = "txtsph6"
        Me.txtsph6.Size = New System.Drawing.Size(86, 20)
        Me.txtsph6.TabIndex = 157
        '
        'txttime3
        '
        Me.txttime3.Enabled = False
        Me.txttime3.Location = New System.Drawing.Point(481, 371)
        Me.txttime3.Name = "txttime3"
        Me.txttime3.Size = New System.Drawing.Size(52, 20)
        Me.txttime3.TabIndex = 135
        '
        'txtspl10
        '
        Me.txtspl10.Enabled = False
        Me.txtspl10.Location = New System.Drawing.Point(296, 644)
        Me.txtspl10.Name = "txtspl10"
        Me.txtspl10.Size = New System.Drawing.Size(81, 20)
        Me.txtspl10.TabIndex = 188
        '
        'txtsph5
        '
        Me.txtsph5.Enabled = False
        Me.txtsph5.Location = New System.Drawing.Point(386, 449)
        Me.txtsph5.Name = "txtsph5"
        Me.txtsph5.Size = New System.Drawing.Size(86, 20)
        Me.txtsph5.TabIndex = 149
        '
        'txtspl9
        '
        Me.txtspl9.Enabled = False
        Me.txtspl9.Location = New System.Drawing.Point(296, 605)
        Me.txtspl9.Name = "txtspl9"
        Me.txtspl9.Size = New System.Drawing.Size(81, 20)
        Me.txtspl9.TabIndex = 180
        '
        'txttimeh1
        '
        Me.txttimeh1.Enabled = False
        Me.txttimeh1.Location = New System.Drawing.Point(616, 293)
        Me.txttimeh1.Name = "txttimeh1"
        Me.txttimeh1.Size = New System.Drawing.Size(65, 20)
        Me.txttimeh1.TabIndex = 121
        '
        'txtspl8
        '
        Me.txtspl8.Enabled = False
        Me.txtspl8.Location = New System.Drawing.Point(294, 566)
        Me.txtspl8.Name = "txtspl8"
        Me.txtspl8.Size = New System.Drawing.Size(81, 20)
        Me.txtspl8.TabIndex = 172
        '
        'txtsph4
        '
        Me.txtsph4.Enabled = False
        Me.txtsph4.Location = New System.Drawing.Point(386, 410)
        Me.txtsph4.Name = "txtsph4"
        Me.txtsph4.Size = New System.Drawing.Size(86, 20)
        Me.txtsph4.TabIndex = 142
        '
        'txtspl7
        '
        Me.txtspl7.Enabled = False
        Me.txtspl7.Location = New System.Drawing.Point(296, 527)
        Me.txtspl7.Name = "txtspl7"
        Me.txtspl7.Size = New System.Drawing.Size(81, 20)
        Me.txtspl7.TabIndex = 164
        '
        'txttime2
        '
        Me.txttime2.Enabled = False
        Me.txttime2.Location = New System.Drawing.Point(481, 332)
        Me.txttime2.Name = "txttime2"
        Me.txttime2.Size = New System.Drawing.Size(52, 20)
        Me.txttime2.TabIndex = 127
        '
        'txtspl6
        '
        Me.txtspl6.Enabled = False
        Me.txtspl6.Location = New System.Drawing.Point(296, 488)
        Me.txtspl6.Name = "txtspl6"
        Me.txtspl6.Size = New System.Drawing.Size(81, 20)
        Me.txtspl6.TabIndex = 156
        '
        'txtsph3
        '
        Me.txtsph3.Enabled = False
        Me.txtsph3.Location = New System.Drawing.Point(386, 371)
        Me.txtsph3.Name = "txtsph3"
        Me.txtsph3.Size = New System.Drawing.Size(86, 20)
        Me.txtsph3.TabIndex = 134
        '
        'txtsp10
        '
        Me.txtsp10.Enabled = False
        Me.txtsp10.Location = New System.Drawing.Point(188, 644)
        Me.txtsp10.Name = "txtsp10"
        Me.txtsp10.Size = New System.Drawing.Size(99, 20)
        Me.txtsp10.TabIndex = 187
        '
        'txtspl5
        '
        Me.txtspl5.Enabled = False
        Me.txtspl5.Location = New System.Drawing.Point(296, 449)
        Me.txtspl5.Name = "txtspl5"
        Me.txtspl5.Size = New System.Drawing.Size(81, 20)
        Me.txtspl5.TabIndex = 148
        '
        'txtsp9
        '
        Me.txtsp9.Enabled = False
        Me.txtsp9.Location = New System.Drawing.Point(188, 605)
        Me.txtsp9.Name = "txtsp9"
        Me.txtsp9.Size = New System.Drawing.Size(99, 20)
        Me.txtsp9.TabIndex = 179
        '
        'txttimel1
        '
        Me.txttimel1.Enabled = False
        Me.txttimel1.Location = New System.Drawing.Point(542, 293)
        Me.txttimel1.Name = "txttimel1"
        Me.txttimel1.Size = New System.Drawing.Size(65, 20)
        Me.txttimel1.TabIndex = 120
        '
        'txtsp8
        '
        Me.txtsp8.Enabled = False
        Me.txtsp8.Location = New System.Drawing.Point(186, 566)
        Me.txtsp8.Name = "txtsp8"
        Me.txtsp8.Size = New System.Drawing.Size(99, 20)
        Me.txtsp8.TabIndex = 171
        '
        'txtspl4
        '
        Me.txtspl4.Enabled = False
        Me.txtspl4.Location = New System.Drawing.Point(296, 410)
        Me.txtspl4.Name = "txtspl4"
        Me.txtspl4.Size = New System.Drawing.Size(81, 20)
        Me.txtspl4.TabIndex = 141
        '
        'txtsp7
        '
        Me.txtsp7.Enabled = False
        Me.txtsp7.Location = New System.Drawing.Point(188, 527)
        Me.txtsp7.Name = "txtsp7"
        Me.txtsp7.Size = New System.Drawing.Size(99, 20)
        Me.txtsp7.TabIndex = 163
        '
        'txtsph2
        '
        Me.txtsph2.Enabled = False
        Me.txtsph2.Location = New System.Drawing.Point(386, 332)
        Me.txtsph2.Name = "txtsph2"
        Me.txtsph2.Size = New System.Drawing.Size(86, 20)
        Me.txtsph2.TabIndex = 126
        '
        'txtsp6
        '
        Me.txtsp6.Enabled = False
        Me.txtsp6.Location = New System.Drawing.Point(188, 488)
        Me.txtsp6.Name = "txtsp6"
        Me.txtsp6.Size = New System.Drawing.Size(99, 20)
        Me.txtsp6.TabIndex = 155
        '
        'txtspl3
        '
        Me.txtspl3.Enabled = False
        Me.txtspl3.Location = New System.Drawing.Point(296, 371)
        Me.txtspl3.Name = "txtspl3"
        Me.txtspl3.Size = New System.Drawing.Size(81, 20)
        Me.txtspl3.TabIndex = 133
        '
        'txtsp5
        '
        Me.txtsp5.Enabled = False
        Me.txtsp5.Location = New System.Drawing.Point(188, 449)
        Me.txtsp5.Name = "txtsp5"
        Me.txtsp5.Size = New System.Drawing.Size(99, 20)
        Me.txtsp5.TabIndex = 147
        '
        'txttime1
        '
        Me.txttime1.Enabled = False
        Me.txttime1.Location = New System.Drawing.Point(481, 293)
        Me.txttime1.Name = "txttime1"
        Me.txttime1.Size = New System.Drawing.Size(52, 20)
        Me.txttime1.TabIndex = 119
        '
        'txtsp4
        '
        Me.txtsp4.Enabled = False
        Me.txtsp4.Location = New System.Drawing.Point(188, 410)
        Me.txtsp4.Name = "txtsp4"
        Me.txtsp4.Size = New System.Drawing.Size(99, 20)
        Me.txtsp4.TabIndex = 140
        '
        'txtspl2
        '
        Me.txtspl2.Enabled = False
        Me.txtspl2.Location = New System.Drawing.Point(296, 332)
        Me.txtspl2.Name = "txtspl2"
        Me.txtspl2.Size = New System.Drawing.Size(81, 20)
        Me.txtspl2.TabIndex = 125
        '
        'txtsp3
        '
        Me.txtsp3.Enabled = False
        Me.txtsp3.Location = New System.Drawing.Point(188, 371)
        Me.txtsp3.Name = "txtsp3"
        Me.txtsp3.Size = New System.Drawing.Size(99, 20)
        Me.txtsp3.TabIndex = 132
        '
        'txtsph1
        '
        Me.txtsph1.Enabled = False
        Me.txtsph1.Location = New System.Drawing.Point(386, 293)
        Me.txtsph1.Name = "txtsph1"
        Me.txtsph1.Size = New System.Drawing.Size(86, 20)
        Me.txtsph1.TabIndex = 118
        '
        'txtsp2
        '
        Me.txtsp2.Enabled = False
        Me.txtsp2.Location = New System.Drawing.Point(188, 332)
        Me.txtsp2.Name = "txtsp2"
        Me.txtsp2.Size = New System.Drawing.Size(99, 20)
        Me.txtsp2.TabIndex = 124
        '
        'txtspl1
        '
        Me.txtspl1.Enabled = False
        Me.txtspl1.Location = New System.Drawing.Point(296, 293)
        Me.txtspl1.Name = "txtspl1"
        Me.txtspl1.Size = New System.Drawing.Size(81, 20)
        Me.txtspl1.TabIndex = 117
        '
        'txtsp1
        '
        Me.txtsp1.Enabled = False
        Me.txtsp1.Location = New System.Drawing.Point(188, 293)
        Me.txtsp1.Name = "txtsp1"
        Me.txtsp1.Size = New System.Drawing.Size(99, 20)
        Me.txtsp1.TabIndex = 116
        '
        'Chart1
        '
        Me.Chart1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom
        Me.Chart1.BackSecondaryColor = System.Drawing.Color.LightSkyBlue
        Me.Chart1.BorderlineColor = System.Drawing.Color.Black
        Me.Chart1.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea1.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea1)
        Legend1.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend1)
        Me.Chart1.Location = New System.Drawing.Point(6, 35)
        Me.Chart1.Name = "Chart1"
        Series1.ChartArea = "ChartArea1"
        Series1.Legend = "Legend1"
        Series1.Name = "Series1"
        Me.Chart1.Series.Add(Series1)
        Me.Chart1.Size = New System.Drawing.Size(697, 239)
        Me.Chart1.TabIndex = 93
        Me.Chart1.TabStop = False
        Me.Chart1.Text = "Chart1"
        Me.ToolTip1.SetToolTip(Me.Chart1, "Graphical display of cure cycle." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Click update to show cure cycle changes.")
        '
        'Lbl106
        '
        Me.Lbl106.AutoSize = True
        Me.Lbl106.Location = New System.Drawing.Point(611, 628)
        Me.Lbl106.Name = "Lbl106"
        Me.Lbl106.Size = New System.Drawing.Size(70, 13)
        Me.Lbl106.TabIndex = 113
        Me.Lbl106.Text = "Time High (F)"
        '
        'Lbl96
        '
        Me.Lbl96.AutoSize = True
        Me.Lbl96.Location = New System.Drawing.Point(611, 589)
        Me.Lbl96.Name = "Lbl96"
        Me.Lbl96.Size = New System.Drawing.Size(70, 13)
        Me.Lbl96.TabIndex = 113
        Me.Lbl96.Text = "Time High (F)"
        '
        'Lbl86
        '
        Me.Lbl86.AutoSize = True
        Me.Lbl86.Location = New System.Drawing.Point(611, 550)
        Me.Lbl86.Name = "Lbl86"
        Me.Lbl86.Size = New System.Drawing.Size(70, 13)
        Me.Lbl86.TabIndex = 113
        Me.Lbl86.Text = "Time High (F)"
        '
        'Lbl76
        '
        Me.Lbl76.AutoSize = True
        Me.Lbl76.Location = New System.Drawing.Point(611, 511)
        Me.Lbl76.Name = "Lbl76"
        Me.Lbl76.Size = New System.Drawing.Size(70, 13)
        Me.Lbl76.TabIndex = 113
        Me.Lbl76.Text = "Time High (F)"
        '
        'Lbl66
        '
        Me.Lbl66.AutoSize = True
        Me.Lbl66.Location = New System.Drawing.Point(613, 472)
        Me.Lbl66.Name = "Lbl66"
        Me.Lbl66.Size = New System.Drawing.Size(70, 13)
        Me.Lbl66.TabIndex = 113
        Me.Lbl66.Text = "Time High (F)"
        '
        'Lbl56
        '
        Me.Lbl56.AutoSize = True
        Me.Lbl56.Location = New System.Drawing.Point(613, 433)
        Me.Lbl56.Name = "Lbl56"
        Me.Lbl56.Size = New System.Drawing.Size(70, 13)
        Me.Lbl56.TabIndex = 113
        Me.Lbl56.Text = "Time High (F)"
        '
        'Lbl46
        '
        Me.Lbl46.AutoSize = True
        Me.Lbl46.Location = New System.Drawing.Point(613, 394)
        Me.Lbl46.Name = "Lbl46"
        Me.Lbl46.Size = New System.Drawing.Size(70, 13)
        Me.Lbl46.TabIndex = 113
        Me.Lbl46.Text = "Time High (F)"
        '
        'Lbl36
        '
        Me.Lbl36.AutoSize = True
        Me.Lbl36.Location = New System.Drawing.Point(613, 355)
        Me.Lbl36.Name = "Lbl36"
        Me.Lbl36.Size = New System.Drawing.Size(70, 13)
        Me.Lbl36.TabIndex = 113
        Me.Lbl36.Text = "Time High (F)"
        '
        'Lbl26
        '
        Me.Lbl26.AutoSize = True
        Me.Lbl26.Location = New System.Drawing.Point(613, 316)
        Me.Lbl26.Name = "Lbl26"
        Me.Lbl26.Size = New System.Drawing.Size(70, 13)
        Me.Lbl26.TabIndex = 113
        Me.Lbl26.Text = "Time High (F)"
        '
        'Lbl105
        '
        Me.Lbl105.AutoSize = True
        Me.Lbl105.Location = New System.Drawing.Point(537, 628)
        Me.Lbl105.Name = "Lbl105"
        Me.Lbl105.Size = New System.Drawing.Size(68, 13)
        Me.Lbl105.TabIndex = 112
        Me.Lbl105.Text = "Time Low (F)"
        '
        'Lbl95
        '
        Me.Lbl95.AutoSize = True
        Me.Lbl95.Location = New System.Drawing.Point(537, 589)
        Me.Lbl95.Name = "Lbl95"
        Me.Lbl95.Size = New System.Drawing.Size(68, 13)
        Me.Lbl95.TabIndex = 112
        Me.Lbl95.Text = "Time Low (F)"
        '
        'Lbl85
        '
        Me.Lbl85.AutoSize = True
        Me.Lbl85.Location = New System.Drawing.Point(537, 550)
        Me.Lbl85.Name = "Lbl85"
        Me.Lbl85.Size = New System.Drawing.Size(68, 13)
        Me.Lbl85.TabIndex = 112
        Me.Lbl85.Text = "Time Low (F)"
        '
        'Lbl75
        '
        Me.Lbl75.AutoSize = True
        Me.Lbl75.Location = New System.Drawing.Point(537, 511)
        Me.Lbl75.Name = "Lbl75"
        Me.Lbl75.Size = New System.Drawing.Size(68, 13)
        Me.Lbl75.TabIndex = 112
        Me.Lbl75.Text = "Time Low (F)"
        '
        'Lbl16
        '
        Me.Lbl16.AutoSize = True
        Me.Lbl16.Location = New System.Drawing.Point(613, 277)
        Me.Lbl16.Name = "Lbl16"
        Me.Lbl16.Size = New System.Drawing.Size(70, 13)
        Me.Lbl16.TabIndex = 113
        Me.Lbl16.Text = "Time High (F)"
        '
        'Lbl65
        '
        Me.Lbl65.AutoSize = True
        Me.Lbl65.Location = New System.Drawing.Point(539, 472)
        Me.Lbl65.Name = "Lbl65"
        Me.Lbl65.Size = New System.Drawing.Size(68, 13)
        Me.Lbl65.TabIndex = 112
        Me.Lbl65.Text = "Time Low (F)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(24, 277)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(21, 13)
        Me.Label4.TabIndex = 104
        Me.Label4.Text = "On"
        '
        'Lbl55
        '
        Me.Lbl55.AutoSize = True
        Me.Lbl55.Location = New System.Drawing.Point(539, 433)
        Me.Lbl55.Name = "Lbl55"
        Me.Lbl55.Size = New System.Drawing.Size(68, 13)
        Me.Lbl55.TabIndex = 112
        Me.Lbl55.Text = "Time Low (F)"
        '
        'Lbl45
        '
        Me.Lbl45.AutoSize = True
        Me.Lbl45.Location = New System.Drawing.Point(539, 394)
        Me.Lbl45.Name = "Lbl45"
        Me.Lbl45.Size = New System.Drawing.Size(68, 13)
        Me.Lbl45.TabIndex = 112
        Me.Lbl45.Text = "Time Low (F)"
        '
        'Lbl35
        '
        Me.Lbl35.AutoSize = True
        Me.Lbl35.Location = New System.Drawing.Point(539, 355)
        Me.Lbl35.Name = "Lbl35"
        Me.Lbl35.Size = New System.Drawing.Size(68, 13)
        Me.Lbl35.TabIndex = 112
        Me.Lbl35.Text = "Time Low (F)"
        '
        'Lbl25
        '
        Me.Lbl25.AutoSize = True
        Me.Lbl25.Location = New System.Drawing.Point(539, 316)
        Me.Lbl25.Name = "Lbl25"
        Me.Lbl25.Size = New System.Drawing.Size(68, 13)
        Me.Lbl25.TabIndex = 112
        Me.Lbl25.Text = "Time Low (F)"
        '
        'Lbl104
        '
        Me.Lbl104.AutoSize = True
        Me.Lbl104.Location = New System.Drawing.Point(476, 628)
        Me.Lbl104.Name = "Lbl104"
        Me.Lbl104.Size = New System.Drawing.Size(55, 13)
        Me.Lbl104.TabIndex = 111
        Me.Lbl104.Text = "Time (min)"
        '
        'Lbl94
        '
        Me.Lbl94.AutoSize = True
        Me.Lbl94.Location = New System.Drawing.Point(476, 589)
        Me.Lbl94.Name = "Lbl94"
        Me.Lbl94.Size = New System.Drawing.Size(55, 13)
        Me.Lbl94.TabIndex = 111
        Me.Lbl94.Text = "Time (min)"
        '
        'Lbl84
        '
        Me.Lbl84.AutoSize = True
        Me.Lbl84.Location = New System.Drawing.Point(476, 550)
        Me.Lbl84.Name = "Lbl84"
        Me.Lbl84.Size = New System.Drawing.Size(55, 13)
        Me.Lbl84.TabIndex = 111
        Me.Lbl84.Text = "Time (min)"
        '
        'Lbl74
        '
        Me.Lbl74.AutoSize = True
        Me.Lbl74.Location = New System.Drawing.Point(476, 511)
        Me.Lbl74.Name = "Lbl74"
        Me.Lbl74.Size = New System.Drawing.Size(55, 13)
        Me.Lbl74.TabIndex = 111
        Me.Lbl74.Text = "Time (min)"
        '
        'lblsegment
        '
        Me.lblsegment.AutoSize = True
        Me.lblsegment.Location = New System.Drawing.Point(55, 277)
        Me.lblsegment.Name = "lblsegment"
        Me.lblsegment.Size = New System.Drawing.Size(26, 13)
        Me.lblsegment.TabIndex = 94
        Me.lblsegment.Text = "Seg"
        '
        'Lbl64
        '
        Me.Lbl64.AutoSize = True
        Me.Lbl64.Location = New System.Drawing.Point(478, 472)
        Me.Lbl64.Name = "Lbl64"
        Me.Lbl64.Size = New System.Drawing.Size(55, 13)
        Me.Lbl64.TabIndex = 111
        Me.Lbl64.Text = "Time (min)"
        '
        'Lbl15
        '
        Me.Lbl15.AutoSize = True
        Me.Lbl15.Location = New System.Drawing.Point(539, 277)
        Me.Lbl15.Name = "Lbl15"
        Me.Lbl15.Size = New System.Drawing.Size(68, 13)
        Me.Lbl15.TabIndex = 112
        Me.Lbl15.Text = "Time Low (F)"
        '
        'Lbl54
        '
        Me.Lbl54.AutoSize = True
        Me.Lbl54.Location = New System.Drawing.Point(478, 433)
        Me.Lbl54.Name = "Lbl54"
        Me.Lbl54.Size = New System.Drawing.Size(55, 13)
        Me.Lbl54.TabIndex = 111
        Me.Lbl54.Text = "Time (min)"
        '
        'Lbl44
        '
        Me.Lbl44.AutoSize = True
        Me.Lbl44.Location = New System.Drawing.Point(478, 394)
        Me.Lbl44.Name = "Lbl44"
        Me.Lbl44.Size = New System.Drawing.Size(55, 13)
        Me.Lbl44.TabIndex = 111
        Me.Lbl44.Text = "Time (min)"
        '
        'Lbl34
        '
        Me.Lbl34.AutoSize = True
        Me.Lbl34.Location = New System.Drawing.Point(478, 355)
        Me.Lbl34.Name = "Lbl34"
        Me.Lbl34.Size = New System.Drawing.Size(55, 13)
        Me.Lbl34.TabIndex = 111
        Me.Lbl34.Text = "Time (min)"
        '
        'Lbl101
        '
        Me.Lbl101.AutoSize = True
        Me.Lbl101.Location = New System.Drawing.Point(183, 628)
        Me.Lbl101.Name = "Lbl101"
        Me.Lbl101.Size = New System.Drawing.Size(102, 13)
        Me.Lbl101.TabIndex = 108
        Me.Lbl101.Text = "Setpoint Nominal (F)"
        '
        'Lbl91
        '
        Me.Lbl91.AutoSize = True
        Me.Lbl91.Location = New System.Drawing.Point(183, 589)
        Me.Lbl91.Name = "Lbl91"
        Me.Lbl91.Size = New System.Drawing.Size(102, 13)
        Me.Lbl91.TabIndex = 108
        Me.Lbl91.Text = "Setpoint Nominal (F)"
        '
        'Lbl81
        '
        Me.Lbl81.AutoSize = True
        Me.Lbl81.Location = New System.Drawing.Point(183, 550)
        Me.Lbl81.Name = "Lbl81"
        Me.Lbl81.Size = New System.Drawing.Size(102, 13)
        Me.Lbl81.TabIndex = 108
        Me.Lbl81.Text = "Setpoint Nominal (F)"
        '
        'Lbl71
        '
        Me.Lbl71.AutoSize = True
        Me.Lbl71.Location = New System.Drawing.Point(183, 511)
        Me.Lbl71.Name = "Lbl71"
        Me.Lbl71.Size = New System.Drawing.Size(102, 13)
        Me.Lbl71.TabIndex = 108
        Me.Lbl71.Text = "Setpoint Nominal (F)"
        '
        'Lbl24
        '
        Me.Lbl24.AutoSize = True
        Me.Lbl24.Location = New System.Drawing.Point(478, 316)
        Me.Lbl24.Name = "Lbl24"
        Me.Lbl24.Size = New System.Drawing.Size(55, 13)
        Me.Lbl24.TabIndex = 111
        Me.Lbl24.Text = "Time (min)"
        '
        'Lbl61
        '
        Me.Lbl61.AutoSize = True
        Me.Lbl61.Location = New System.Drawing.Point(185, 472)
        Me.Lbl61.Name = "Lbl61"
        Me.Lbl61.Size = New System.Drawing.Size(102, 13)
        Me.Lbl61.TabIndex = 108
        Me.Lbl61.Text = "Setpoint Nominal (F)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(94, 277)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 13)
        Me.Label7.TabIndex = 107
        Me.Label7.Text = "Segment Type"
        '
        'Lbl102
        '
        Me.Lbl102.AutoSize = True
        Me.Lbl102.Location = New System.Drawing.Point(291, 628)
        Me.Lbl102.Name = "Lbl102"
        Me.Lbl102.Size = New System.Drawing.Size(84, 13)
        Me.Lbl102.TabIndex = 109
        Me.Lbl102.Text = "Setpoint Low (F)"
        '
        'Lbl92
        '
        Me.Lbl92.AutoSize = True
        Me.Lbl92.Location = New System.Drawing.Point(291, 589)
        Me.Lbl92.Name = "Lbl92"
        Me.Lbl92.Size = New System.Drawing.Size(84, 13)
        Me.Lbl92.TabIndex = 109
        Me.Lbl92.Text = "Setpoint Low (F)"
        '
        'Lbl82
        '
        Me.Lbl82.AutoSize = True
        Me.Lbl82.Location = New System.Drawing.Point(291, 550)
        Me.Lbl82.Name = "Lbl82"
        Me.Lbl82.Size = New System.Drawing.Size(84, 13)
        Me.Lbl82.TabIndex = 109
        Me.Lbl82.Text = "Setpoint Low (F)"
        '
        'Lbl51
        '
        Me.Lbl51.AutoSize = True
        Me.Lbl51.Location = New System.Drawing.Point(185, 433)
        Me.Lbl51.Name = "Lbl51"
        Me.Lbl51.Size = New System.Drawing.Size(102, 13)
        Me.Lbl51.TabIndex = 108
        Me.Lbl51.Text = "Setpoint Nominal (F)"
        '
        'Lbl72
        '
        Me.Lbl72.AutoSize = True
        Me.Lbl72.Location = New System.Drawing.Point(291, 511)
        Me.Lbl72.Name = "Lbl72"
        Me.Lbl72.Size = New System.Drawing.Size(84, 13)
        Me.Lbl72.TabIndex = 109
        Me.Lbl72.Text = "Setpoint Low (F)"
        '
        'Lbl41
        '
        Me.Lbl41.AutoSize = True
        Me.Lbl41.Location = New System.Drawing.Point(185, 394)
        Me.Lbl41.Name = "Lbl41"
        Me.Lbl41.Size = New System.Drawing.Size(102, 13)
        Me.Lbl41.TabIndex = 108
        Me.Lbl41.Text = "Setpoint Nominal (F)"
        '
        'Lbl62
        '
        Me.Lbl62.AutoSize = True
        Me.Lbl62.Location = New System.Drawing.Point(293, 472)
        Me.Lbl62.Name = "Lbl62"
        Me.Lbl62.Size = New System.Drawing.Size(84, 13)
        Me.Lbl62.TabIndex = 109
        Me.Lbl62.Text = "Setpoint Low (F)"
        '
        'Lbl103
        '
        Me.Lbl103.AutoSize = True
        Me.Lbl103.Location = New System.Drawing.Point(381, 628)
        Me.Lbl103.Name = "Lbl103"
        Me.Lbl103.Size = New System.Drawing.Size(89, 13)
        Me.Lbl103.TabIndex = 110
        Me.Lbl103.Text = " Setpoint High (F)"
        '
        'Lbl31
        '
        Me.Lbl31.AutoSize = True
        Me.Lbl31.Location = New System.Drawing.Point(185, 355)
        Me.Lbl31.Name = "Lbl31"
        Me.Lbl31.Size = New System.Drawing.Size(102, 13)
        Me.Lbl31.TabIndex = 108
        Me.Lbl31.Text = "Setpoint Nominal (F)"
        '
        'Lbl93
        '
        Me.Lbl93.AutoSize = True
        Me.Lbl93.Location = New System.Drawing.Point(381, 589)
        Me.Lbl93.Name = "Lbl93"
        Me.Lbl93.Size = New System.Drawing.Size(89, 13)
        Me.Lbl93.TabIndex = 110
        Me.Lbl93.Text = " Setpoint High (F)"
        '
        'Lbl52
        '
        Me.Lbl52.AutoSize = True
        Me.Lbl52.Location = New System.Drawing.Point(293, 433)
        Me.Lbl52.Name = "Lbl52"
        Me.Lbl52.Size = New System.Drawing.Size(84, 13)
        Me.Lbl52.TabIndex = 109
        Me.Lbl52.Text = "Setpoint Low (F)"
        '
        'Lbl83
        '
        Me.Lbl83.AutoSize = True
        Me.Lbl83.Location = New System.Drawing.Point(381, 550)
        Me.Lbl83.Name = "Lbl83"
        Me.Lbl83.Size = New System.Drawing.Size(89, 13)
        Me.Lbl83.TabIndex = 110
        Me.Lbl83.Text = " Setpoint High (F)"
        '
        'Lbl21
        '
        Me.Lbl21.AutoSize = True
        Me.Lbl21.Location = New System.Drawing.Point(185, 316)
        Me.Lbl21.Name = "Lbl21"
        Me.Lbl21.Size = New System.Drawing.Size(102, 13)
        Me.Lbl21.TabIndex = 108
        Me.Lbl21.Text = "Setpoint Nominal (F)"
        '
        'Lbl73
        '
        Me.Lbl73.AutoSize = True
        Me.Lbl73.Location = New System.Drawing.Point(381, 511)
        Me.Lbl73.Name = "Lbl73"
        Me.Lbl73.Size = New System.Drawing.Size(89, 13)
        Me.Lbl73.TabIndex = 110
        Me.Lbl73.Text = " Setpoint High (F)"
        '
        'Lbl42
        '
        Me.Lbl42.AutoSize = True
        Me.Lbl42.Location = New System.Drawing.Point(293, 394)
        Me.Lbl42.Name = "Lbl42"
        Me.Lbl42.Size = New System.Drawing.Size(84, 13)
        Me.Lbl42.TabIndex = 109
        Me.Lbl42.Text = "Setpoint Low (F)"
        '
        'Lbl63
        '
        Me.Lbl63.AutoSize = True
        Me.Lbl63.Location = New System.Drawing.Point(383, 472)
        Me.Lbl63.Name = "Lbl63"
        Me.Lbl63.Size = New System.Drawing.Size(89, 13)
        Me.Lbl63.TabIndex = 110
        Me.Lbl63.Text = " Setpoint High (F)"
        '
        'Lbl32
        '
        Me.Lbl32.AutoSize = True
        Me.Lbl32.Location = New System.Drawing.Point(293, 355)
        Me.Lbl32.Name = "Lbl32"
        Me.Lbl32.Size = New System.Drawing.Size(84, 13)
        Me.Lbl32.TabIndex = 109
        Me.Lbl32.Text = "Setpoint Low (F)"
        '
        'Lbl53
        '
        Me.Lbl53.AutoSize = True
        Me.Lbl53.Location = New System.Drawing.Point(383, 433)
        Me.Lbl53.Name = "Lbl53"
        Me.Lbl53.Size = New System.Drawing.Size(89, 13)
        Me.Lbl53.TabIndex = 110
        Me.Lbl53.Text = " Setpoint High (F)"
        '
        'Lbl14
        '
        Me.Lbl14.AutoSize = True
        Me.Lbl14.Location = New System.Drawing.Point(478, 277)
        Me.Lbl14.Name = "Lbl14"
        Me.Lbl14.Size = New System.Drawing.Size(55, 13)
        Me.Lbl14.TabIndex = 111
        Me.Lbl14.Text = "Time (min)"
        '
        'Lbl43
        '
        Me.Lbl43.AutoSize = True
        Me.Lbl43.Location = New System.Drawing.Point(383, 394)
        Me.Lbl43.Name = "Lbl43"
        Me.Lbl43.Size = New System.Drawing.Size(89, 13)
        Me.Lbl43.TabIndex = 110
        Me.Lbl43.Text = " Setpoint High (F)"
        '
        'Lbl22
        '
        Me.Lbl22.AutoSize = True
        Me.Lbl22.Location = New System.Drawing.Point(293, 316)
        Me.Lbl22.Name = "Lbl22"
        Me.Lbl22.Size = New System.Drawing.Size(84, 13)
        Me.Lbl22.TabIndex = 109
        Me.Lbl22.Text = "Setpoint Low (F)"
        '
        'Lbl33
        '
        Me.Lbl33.AutoSize = True
        Me.Lbl33.Location = New System.Drawing.Point(383, 355)
        Me.Lbl33.Name = "Lbl33"
        Me.Lbl33.Size = New System.Drawing.Size(89, 13)
        Me.Lbl33.TabIndex = 110
        Me.Lbl33.Text = " Setpoint High (F)"
        '
        'lbl11
        '
        Me.lbl11.AutoSize = True
        Me.lbl11.Location = New System.Drawing.Point(185, 277)
        Me.lbl11.Name = "lbl11"
        Me.lbl11.Size = New System.Drawing.Size(102, 13)
        Me.lbl11.TabIndex = 108
        Me.lbl11.Text = "Setpoint Nominal (F)"
        '
        'Lbl23
        '
        Me.Lbl23.AutoSize = True
        Me.Lbl23.Location = New System.Drawing.Point(383, 316)
        Me.Lbl23.Name = "Lbl23"
        Me.Lbl23.Size = New System.Drawing.Size(89, 13)
        Me.Lbl23.TabIndex = 110
        Me.Lbl23.Text = " Setpoint High (F)"
        '
        'Lbl12
        '
        Me.Lbl12.AutoSize = True
        Me.Lbl12.Location = New System.Drawing.Point(293, 277)
        Me.Lbl12.Name = "Lbl12"
        Me.Lbl12.Size = New System.Drawing.Size(84, 13)
        Me.Lbl12.TabIndex = 109
        Me.Lbl12.Text = "Setpoint Low (F)"
        '
        'Lbl13
        '
        Me.Lbl13.AutoSize = True
        Me.Lbl13.Location = New System.Drawing.Point(383, 277)
        Me.Lbl13.Name = "Lbl13"
        Me.Lbl13.Size = New System.Drawing.Size(89, 13)
        Me.Lbl13.TabIndex = 110
        Me.Lbl13.Text = " Setpoint High (F)"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label38)
        Me.TabPage3.Controls.Add(Me.Label37)
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Controls.Add(Me.Label3)
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(711, 673)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "PID Settings"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(12, 56)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(525, 13)
        Me.Label38.TabIndex = 9
        Me.Label38.Text = "CHANGE THE OVEN PID SETTINGS MANUALLY AT THE CONTROLLER AND SET PID SETTINGS TO 0" &
    "."
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(12, 35)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(492, 13)
        Me.Label37.TabIndex = 8
        Me.Label37.Text = "PID SETTINGS FOR OVENS ARE NOT SENT TO CONTROLLER BEFORE THE PARTS ARE RUN. "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 86)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 13)
        Me.Label5.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(218, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Enter PID settings for proper cure executioin."
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txtdb2)
        Me.GroupBox5.Controls.Add(Me.Label32)
        Me.GroupBox5.Controls.Add(Me.txthys2)
        Me.GroupBox5.Controls.Add(Me.Label33)
        Me.GroupBox5.Controls.Add(Me.txtderiv2)
        Me.GroupBox5.Controls.Add(Me.Label34)
        Me.GroupBox5.Controls.Add(Me.txtreset2)
        Me.GroupBox5.Controls.Add(Me.Label35)
        Me.GroupBox5.Controls.Add(Me.txtpb2)
        Me.GroupBox5.Controls.Add(Me.Label36)
        Me.GroupBox5.Location = New System.Drawing.Point(6, 239)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(185, 147)
        Me.GroupBox5.TabIndex = 5
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Cooling PID Settings"
        '
        'txtdb2
        '
        Me.txtdb2.Location = New System.Drawing.Point(88, 121)
        Me.txtdb2.Name = "txtdb2"
        Me.txtdb2.Size = New System.Drawing.Size(91, 20)
        Me.txtdb2.TabIndex = 4
        Me.txtdb2.Text = "0"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(6, 124)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(76, 13)
        Me.Label32.TabIndex = 3
        Me.Label32.Text = "Dead Band (F)"
        '
        'txthys2
        '
        Me.txthys2.Location = New System.Drawing.Point(78, 97)
        Me.txthys2.Name = "txthys2"
        Me.txthys2.Size = New System.Drawing.Size(101, 20)
        Me.txthys2.TabIndex = 3
        Me.txthys2.Text = "0"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(6, 100)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(66, 13)
        Me.Label33.TabIndex = 3
        Me.Label33.Text = "Hysterisis (F)"
        '
        'txtderiv2
        '
        Me.txtderiv2.Location = New System.Drawing.Point(115, 71)
        Me.txtderiv2.Name = "txtderiv2"
        Me.txtderiv2.Size = New System.Drawing.Size(64, 20)
        Me.txtderiv2.TabIndex = 2
        Me.txtderiv2.Text = "0"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(6, 74)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(96, 13)
        Me.Label34.TabIndex = 3
        Me.Label34.Text = "Derivative Rate (F)"
        '
        'txtreset2
        '
        Me.txtreset2.Location = New System.Drawing.Point(115, 45)
        Me.txtreset2.Name = "txtreset2"
        Me.txtreset2.Size = New System.Drawing.Size(64, 20)
        Me.txtreset2.TabIndex = 1
        Me.txtreset2.Text = "0"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(6, 48)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(103, 13)
        Me.Label35.TabIndex = 3
        Me.Label35.Text = "Integral Reset (/min)"
        '
        'txtpb2
        '
        Me.txtpb2.Location = New System.Drawing.Point(117, 19)
        Me.txtpb2.Name = "txtpb2"
        Me.txtpb2.Size = New System.Drawing.Size(62, 20)
        Me.txtpb2.TabIndex = 0
        Me.txtpb2.Text = "0"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(6, 22)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(106, 13)
        Me.Label36.TabIndex = 3
        Me.Label36.Text = "Proportional Band (F)"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtdb1)
        Me.GroupBox4.Controls.Add(Me.Label31)
        Me.GroupBox4.Controls.Add(Me.txthys1)
        Me.GroupBox4.Controls.Add(Me.Label30)
        Me.GroupBox4.Controls.Add(Me.txtderiv1)
        Me.GroupBox4.Controls.Add(Me.Label29)
        Me.GroupBox4.Controls.Add(Me.txtreset1)
        Me.GroupBox4.Controls.Add(Me.Label28)
        Me.GroupBox4.Controls.Add(Me.txtpb1)
        Me.GroupBox4.Controls.Add(Me.Label27)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 86)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(185, 147)
        Me.GroupBox4.TabIndex = 6
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Heat PID Settings"
        '
        'txtdb1
        '
        Me.txtdb1.Location = New System.Drawing.Point(88, 121)
        Me.txtdb1.Name = "txtdb1"
        Me.txtdb1.Size = New System.Drawing.Size(91, 20)
        Me.txtdb1.TabIndex = 4
        Me.txtdb1.Text = "0"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(6, 124)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(76, 13)
        Me.Label31.TabIndex = 3
        Me.Label31.Text = "Dead Band (F)"
        '
        'txthys1
        '
        Me.txthys1.Location = New System.Drawing.Point(78, 97)
        Me.txthys1.Name = "txthys1"
        Me.txthys1.Size = New System.Drawing.Size(101, 20)
        Me.txthys1.TabIndex = 3
        Me.txthys1.Text = "0"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(6, 100)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(66, 13)
        Me.Label30.TabIndex = 3
        Me.Label30.Text = "Hysterisis (F)"
        '
        'txtderiv1
        '
        Me.txtderiv1.Location = New System.Drawing.Point(115, 71)
        Me.txtderiv1.Name = "txtderiv1"
        Me.txtderiv1.Size = New System.Drawing.Size(64, 20)
        Me.txtderiv1.TabIndex = 2
        Me.txtderiv1.Text = "0"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(6, 74)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(96, 13)
        Me.Label29.TabIndex = 3
        Me.Label29.Text = "Derivative Rate (F)"
        '
        'txtreset1
        '
        Me.txtreset1.Location = New System.Drawing.Point(115, 45)
        Me.txtreset1.Name = "txtreset1"
        Me.txtreset1.Size = New System.Drawing.Size(64, 20)
        Me.txtreset1.TabIndex = 1
        Me.txtreset1.Text = "0"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(6, 48)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(103, 13)
        Me.Label28.TabIndex = 3
        Me.Label28.Text = "Integral Reset (/min)"
        '
        'txtpb1
        '
        Me.txtpb1.Location = New System.Drawing.Point(117, 19)
        Me.txtpb1.Name = "txtpb1"
        Me.txtpb1.Size = New System.Drawing.Size(62, 20)
        Me.txtpb1.TabIndex = 0
        Me.txtpb1.Text = "0"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(6, 22)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(106, 13)
        Me.Label27.TabIndex = 3
        Me.Label27.Text = "Proportional Band (F)"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ToolsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(732, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.SaveToolStripMenuItem, Me.OpenToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdateInitialCureChartToolStripMenuItem, Me.UpdateSecondaryPostCureChartToolStripMenuItem, Me.ClearToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'UpdateInitialCureChartToolStripMenuItem
        '
        Me.UpdateInitialCureChartToolStripMenuItem.Name = "UpdateInitialCureChartToolStripMenuItem"
        Me.UpdateInitialCureChartToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.UpdateInitialCureChartToolStripMenuItem.Text = "Update Initial Cure Chart"
        '
        'UpdateSecondaryPostCureChartToolStripMenuItem
        '
        Me.UpdateSecondaryPostCureChartToolStripMenuItem.Name = "UpdateSecondaryPostCureChartToolStripMenuItem"
        Me.UpdateSecondaryPostCureChartToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.UpdateSecondaryPostCureChartToolStripMenuItem.Text = "Update Secondary Post Cure Chart"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StationInformationToolStripMenuItem, Me.AllToolStripMenuItem})
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.ClearToolStripMenuItem.Text = "Clear"
        '
        'StationInformationToolStripMenuItem
        '
        Me.StationInformationToolStripMenuItem.Name = "StationInformationToolStripMenuItem"
        Me.StationInformationToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.StationInformationToolStripMenuItem.Text = "Station Information"
        '
        'AllToolStripMenuItem
        '
        Me.AllToolStripMenuItem.Name = "AllToolStripMenuItem"
        Me.AllToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.AllToolStripMenuItem.Text = "All"
        '
        'FrmPartRecipeSetup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(732, 733)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmPartRecipeSetup"
        Me.Text = "Part Recipe Setup"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents cbodelete As System.Windows.Forms.Button
    Friend WithEvents lstavailablestations As System.Windows.Forms.ListBox
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents lststations As System.Windows.Forms.ListBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtpartnumber As System.Windows.Forms.TextBox
    Friend WithEvents txtpartname As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents btnupdatechart1 As System.Windows.Forms.Button
    Friend WithEvents CheckBox10 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox9 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox8 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox7 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents cbo10 As System.Windows.Forms.ComboBox
    Friend WithEvents cbo9 As System.Windows.Forms.ComboBox
    Friend WithEvents cbo8 As System.Windows.Forms.ComboBox
    Friend WithEvents cbo7 As System.Windows.Forms.ComboBox
    Friend WithEvents cbo6 As System.Windows.Forms.ComboBox
    Friend WithEvents cbo5 As System.Windows.Forms.ComboBox
    Friend WithEvents cbo4 As System.Windows.Forms.ComboBox
    Friend WithEvents cbo3 As System.Windows.Forms.ComboBox
    Friend WithEvents cbo2 As System.Windows.Forms.ComboBox
    Friend WithEvents cbo1 As System.Windows.Forms.ComboBox
    Friend WithEvents txttimeh10 As System.Windows.Forms.TextBox
    Friend WithEvents txttimel10 As System.Windows.Forms.TextBox
    Friend WithEvents txttimeh9 As System.Windows.Forms.TextBox
    Friend WithEvents txttimel9 As System.Windows.Forms.TextBox
    Friend WithEvents txttimeh8 As System.Windows.Forms.TextBox
    Friend WithEvents txttimel8 As System.Windows.Forms.TextBox
    Friend WithEvents txttimeh7 As System.Windows.Forms.TextBox
    Friend WithEvents txttimel7 As System.Windows.Forms.TextBox
    Friend WithEvents txttimeh6 As System.Windows.Forms.TextBox
    Friend WithEvents txttimel6 As System.Windows.Forms.TextBox
    Friend WithEvents txttimeh5 As System.Windows.Forms.TextBox
    Friend WithEvents txttime10 As System.Windows.Forms.TextBox
    Friend WithEvents txttimel5 As System.Windows.Forms.TextBox
    Friend WithEvents txttime9 As System.Windows.Forms.TextBox
    Friend WithEvents txttimeh4 As System.Windows.Forms.TextBox
    Friend WithEvents txttime8 As System.Windows.Forms.TextBox
    Friend WithEvents txttimel4 As System.Windows.Forms.TextBox
    Friend WithEvents txttime7 As System.Windows.Forms.TextBox
    Friend WithEvents txttimeh3 As System.Windows.Forms.TextBox
    Friend WithEvents txttime6 As System.Windows.Forms.TextBox
    Friend WithEvents txttimel3 As System.Windows.Forms.TextBox
    Friend WithEvents txtsph10 As System.Windows.Forms.TextBox
    Friend WithEvents txttime5 As System.Windows.Forms.TextBox
    Friend WithEvents txtsph9 As System.Windows.Forms.TextBox
    Friend WithEvents txttimeh2 As System.Windows.Forms.TextBox
    Friend WithEvents txtsph8 As System.Windows.Forms.TextBox
    Friend WithEvents txttime4 As System.Windows.Forms.TextBox
    Friend WithEvents txtsph7 As System.Windows.Forms.TextBox
    Friend WithEvents txttimel2 As System.Windows.Forms.TextBox
    Friend WithEvents txtsph6 As System.Windows.Forms.TextBox
    Friend WithEvents txttime3 As System.Windows.Forms.TextBox
    Friend WithEvents txtspl10 As System.Windows.Forms.TextBox
    Friend WithEvents txtsph5 As System.Windows.Forms.TextBox
    Friend WithEvents txtspl9 As System.Windows.Forms.TextBox
    Friend WithEvents txttimeh1 As System.Windows.Forms.TextBox
    Friend WithEvents txtspl8 As System.Windows.Forms.TextBox
    Friend WithEvents txtsph4 As System.Windows.Forms.TextBox
    Friend WithEvents txtspl7 As System.Windows.Forms.TextBox
    Friend WithEvents txttime2 As System.Windows.Forms.TextBox
    Friend WithEvents txtspl6 As System.Windows.Forms.TextBox
    Friend WithEvents txtsph3 As System.Windows.Forms.TextBox
    Friend WithEvents txtsp10 As System.Windows.Forms.TextBox
    Friend WithEvents txtspl5 As System.Windows.Forms.TextBox
    Friend WithEvents txtsp9 As System.Windows.Forms.TextBox
    Friend WithEvents txttimel1 As System.Windows.Forms.TextBox
    Friend WithEvents txtsp8 As System.Windows.Forms.TextBox
    Friend WithEvents txtspl4 As System.Windows.Forms.TextBox
    Friend WithEvents txtsp7 As System.Windows.Forms.TextBox
    Friend WithEvents txtsph2 As System.Windows.Forms.TextBox
    Friend WithEvents txtsp6 As System.Windows.Forms.TextBox
    Friend WithEvents txtspl3 As System.Windows.Forms.TextBox
    Friend WithEvents txtsp5 As System.Windows.Forms.TextBox
    Friend WithEvents txttime1 As System.Windows.Forms.TextBox
    Friend WithEvents txtsp4 As System.Windows.Forms.TextBox
    Friend WithEvents txtspl2 As System.Windows.Forms.TextBox
    Friend WithEvents txtsp3 As System.Windows.Forms.TextBox
    Friend WithEvents txtsph1 As System.Windows.Forms.TextBox
    Friend WithEvents txtsp2 As System.Windows.Forms.TextBox
    Friend WithEvents txtspl1 As System.Windows.Forms.TextBox
    Friend WithEvents txtsp1 As System.Windows.Forms.TextBox
    Friend WithEvents Chart1 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents Lbl16 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblsegment As System.Windows.Forms.Label
    Friend WithEvents Lbl15 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Lbl14 As System.Windows.Forms.Label
    Friend WithEvents lbl11 As System.Windows.Forms.Label
    Friend WithEvents Lbl12 As System.Windows.Forms.Label
    Friend WithEvents Lbl13 As System.Windows.Forms.Label
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents txtdb2 As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txthys2 As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents txtderiv2 As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txtreset2 As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtpb2 As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtdb1 As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txthys1 As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtderiv1 As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtreset1 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtpb1 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateInitialCureChartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateSecondaryPostCureChartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StationInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Lbl106 As System.Windows.Forms.Label
    Friend WithEvents Lbl96 As System.Windows.Forms.Label
    Friend WithEvents Lbl86 As System.Windows.Forms.Label
    Friend WithEvents Lbl76 As System.Windows.Forms.Label
    Friend WithEvents Lbl66 As System.Windows.Forms.Label
    Friend WithEvents Lbl56 As System.Windows.Forms.Label
    Friend WithEvents Lbl46 As System.Windows.Forms.Label
    Friend WithEvents Lbl36 As System.Windows.Forms.Label
    Friend WithEvents Lbl26 As System.Windows.Forms.Label
    Friend WithEvents Lbl105 As System.Windows.Forms.Label
    Friend WithEvents Lbl95 As System.Windows.Forms.Label
    Friend WithEvents Lbl85 As System.Windows.Forms.Label
    Friend WithEvents Lbl75 As System.Windows.Forms.Label
    Friend WithEvents Lbl65 As System.Windows.Forms.Label
    Friend WithEvents Lbl55 As System.Windows.Forms.Label
    Friend WithEvents Lbl45 As System.Windows.Forms.Label
    Friend WithEvents Lbl35 As System.Windows.Forms.Label
    Friend WithEvents Lbl25 As System.Windows.Forms.Label
    Friend WithEvents Lbl104 As System.Windows.Forms.Label
    Friend WithEvents Lbl94 As System.Windows.Forms.Label
    Friend WithEvents Lbl84 As System.Windows.Forms.Label
    Friend WithEvents Lbl74 As System.Windows.Forms.Label
    Friend WithEvents Lbl64 As System.Windows.Forms.Label
    Friend WithEvents Lbl54 As System.Windows.Forms.Label
    Friend WithEvents Lbl44 As System.Windows.Forms.Label
    Friend WithEvents Lbl34 As System.Windows.Forms.Label
    Friend WithEvents Lbl101 As System.Windows.Forms.Label
    Friend WithEvents Lbl91 As System.Windows.Forms.Label
    Friend WithEvents Lbl81 As System.Windows.Forms.Label
    Friend WithEvents Lbl71 As System.Windows.Forms.Label
    Friend WithEvents Lbl24 As System.Windows.Forms.Label
    Friend WithEvents Lbl61 As System.Windows.Forms.Label
    Friend WithEvents Lbl102 As System.Windows.Forms.Label
    Friend WithEvents Lbl92 As System.Windows.Forms.Label
    Friend WithEvents Lbl82 As System.Windows.Forms.Label
    Friend WithEvents Lbl51 As System.Windows.Forms.Label
    Friend WithEvents Lbl72 As System.Windows.Forms.Label
    Friend WithEvents Lbl41 As System.Windows.Forms.Label
    Friend WithEvents Lbl62 As System.Windows.Forms.Label
    Friend WithEvents Lbl103 As System.Windows.Forms.Label
    Friend WithEvents Lbl31 As System.Windows.Forms.Label
    Friend WithEvents Lbl93 As System.Windows.Forms.Label
    Friend WithEvents Lbl52 As System.Windows.Forms.Label
    Friend WithEvents Lbl83 As System.Windows.Forms.Label
    Friend WithEvents Lbl21 As System.Windows.Forms.Label
    Friend WithEvents Lbl73 As System.Windows.Forms.Label
    Friend WithEvents Lbl42 As System.Windows.Forms.Label
    Friend WithEvents Lbl63 As System.Windows.Forms.Label
    Friend WithEvents Lbl32 As System.Windows.Forms.Label
    Friend WithEvents Lbl53 As System.Windows.Forms.Label
    Friend WithEvents Lbl43 As System.Windows.Forms.Label
    Friend WithEvents Lbl22 As System.Windows.Forms.Label
    Friend WithEvents Lbl33 As System.Windows.Forms.Label
    Friend WithEvents Lbl23 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents chkusepreheat As System.Windows.Forms.CheckBox
    Friend WithEvents txtpreheattime As System.Windows.Forms.TextBox
    Friend WithEvents txtpreheath As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtpreheatl As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtpreheat As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
End Class
